import argparse
import json
import sys


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--image', required=True)
    parser.add_argument('--model', default='yolov8n.pt')
    parser.add_argument('--conf', default='0.25')
    args = parser.parse_args()

    image_path = str(args.image)
    model_name = str(args.model)

    try:
        conf = float(args.conf)
    except Exception:
        conf = 0.25

    try:
        from ultralytics import YOLO  # type: ignore
    except Exception as e:
        print(json.dumps({
            'ok': False,
            'error': 'Missing Python dependency: ultralytics. Install with: pip install ultralytics',
            'detail': str(e)
        }))
        return 2

    try:
        model = YOLO(model_name)
        results = model.predict(source=image_path, conf=conf, verbose=False)

        detections = []
        for r in results:
            names = r.names or {}
            boxes = getattr(r, 'boxes', None)
            if boxes is None:
                continue

            for b in boxes:
                try:
                    cls_id = int(b.cls[0])
                    score = float(b.conf[0])
                    xyxy = [float(x) for x in b.xyxy[0].tolist()]
                    class_name = str(names.get(cls_id, str(cls_id)))
                    detections.append({
                        'classId': cls_id,
                        'className': class_name,
                        'confidence': score,
                        'box': {
                            'x1': xyxy[0],
                            'y1': xyxy[1],
                            'x2': xyxy[2],
                            'y2': xyxy[3]
                        }
                    })
                except Exception:
                    continue

        counts = {}
        for d in detections:
            k = d.get('className', 'unknown')
            counts[k] = int(counts.get(k, 0)) + 1

        out = {
            'ok': True,
            'model': model_name,
            'confidenceThreshold': conf,
            'detections': detections,
            'summary': {
                'total': len(detections),
                'counts': counts
            }
        }

        print(json.dumps(out))
        return 0

    except Exception as e:
        print(json.dumps({
            'ok': False,
            'error': 'YOLO inference failed',
            'detail': str(e)
        }))
        return 1


if __name__ == '__main__':
    sys.exit(main())
