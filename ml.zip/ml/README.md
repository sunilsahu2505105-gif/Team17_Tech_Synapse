# YOLOv8 (local image detection)

This project includes an optional YOLOv8 image detection endpoint at `POST /api/detect`.

## Requirements

- Python 3.9+
- Install Ultralytics YOLO:

`pip install ultralytics`

On first run, Ultralytics will download the default model weights (by default `yolov8n.pt`).

## Environment variables (optional)

- `YOLO_PYTHON` (default: `python`)
- `YOLO_MODEL` (default: `yolov8n.pt`)
- `YOLO_CONF` (default: `0.25`)

## API

`POST /api/detect` (multipart form-data)

- field: `photo` (image)

Returns JSON with detected objects and counts.
