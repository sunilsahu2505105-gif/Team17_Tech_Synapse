(function(){
  const API_BASE = '';
  const TOKEN_KEY = 'carehub_token_v1';

  const THEME_KEY = 'carehub_theme_v1';

  function $(sel){ return document.querySelector(sel); }
  function $all(sel){ return Array.from(document.querySelectorAll(sel)); }

  function safeParse(json, fallback){
    try{ return JSON.parse(json ?? ''); }catch{ return fallback; }
  }

  function parseJwt(token){
    try{
      const parts = String(token || '').split('.');
      if(parts.length !== 3) return null;
      const payload = parts[1].replace(/-/g,'+').replace(/_/g,'/');
      const json = atob(payload.padEnd(payload.length + (4 - payload.length % 4) % 4, '='));
      return safeParse(json, null);
    }catch{ return null; }
  }

  function getRole(){
    const token = getToken();
    const p = token ? parseJwt(token) : null;
    return p && p.role ? String(p.role) : '';
  }

  function resolveInitialTheme(){
    const saved = String(localStorage.getItem(THEME_KEY) || '').trim();
    if(saved === 'light' || saved === 'dark') return saved;

    try{
      const prefersLight = window.matchMedia && window.matchMedia('(prefers-color-scheme: light)').matches;
      return prefersLight ? 'light' : 'dark';
    }catch{
      return 'dark';
    }
  }

  function getTheme(){
    return document.documentElement?.dataset?.theme || 'dark';
  }

  function updateThemeToggle(){
    const btn = document.getElementById('themeToggle');
    if(!btn) return;

    const theme = getTheme();
    const nextLabel = theme === 'dark' ? 'Day' : 'Night';
    btn.textContent = nextLabel;
    btn.title = theme === 'dark' ? 'Switch to Day (light) theme' : 'Switch to Night (dark) theme';
    btn.setAttribute('aria-pressed', theme === 'light' ? 'true' : 'false');
  }

  function applyTheme(theme){
    if(theme !== 'light' && theme !== 'dark') theme = 'dark';
    if(document.documentElement) document.documentElement.dataset.theme = theme;
    updateThemeToggle();
  }

  function setTheme(theme){
    localStorage.setItem(THEME_KEY, theme);
    applyTheme(theme);
  }

  function toggleTheme(){
    setTheme(getTheme() === 'dark' ? 'light' : 'dark');
  }

  // Apply ASAP to reduce theme "flash" on load
  applyTheme(resolveInitialTheme());

  function setNotice(el, text, kind){
    if(!el) return;
    el.textContent = text;
    el.classList.remove('good','bad');
    if(kind) el.classList.add(kind);
    el.hidden = !text;
  }

  function formatYoloSummary(result){
    const r = result && result.result ? result.result : result;
    const ok = r && r.ok;
    if(!r) return 'No detection result.';
    if(ok === false) return r.error ? `Detection failed: ${r.error}` : 'Detection failed.';

    const summary = r.summary || {};
    const total = Number(summary.total || 0);
    const counts = summary.counts || {};
    const parts = Object.entries(counts)
      .sort((a,b) => Number(b[1]) - Number(a[1]))
      .slice(0, 6)
      .map(([k,v]) => `${k}: ${v}`);

    if(!total) return 'YOLOv8: no objects detected.';
    return `YOLOv8: ${total} objects detected (${parts.join(', ')}).`;
  }

  async function runYoloOnFile(file){
    if(!(file instanceof Blob)) throw new Error('Image file is missing');
    const fd = new FormData();
    fd.set('photo', file, file && file.name ? file.name : 'image.jpg');
    return api('/api/detect', { method: 'POST', body: fd });
  }

  function getToken(){
    return String(localStorage.getItem(TOKEN_KEY) || '').trim();
  }

  function setToken(token){
    if(token) localStorage.setItem(TOKEN_KEY, String(token));
  }

  function clearToken(){
    localStorage.removeItem(TOKEN_KEY);
  }

  function getAuth(){
    const token = getToken();
    return { loggedIn: !!token, token };
  }

  async function api(path, opts){
    const options = Object.assign({ method: 'GET', headers: {} }, opts || {});

    const token = getToken();
    const headers = Object.assign({}, options.headers);
    if(token) headers.Authorization = `Bearer ${token}`;

    let body = options.body;
    if(body && typeof body === 'object' && !(body instanceof FormData)){
      headers['Content-Type'] = headers['Content-Type'] || 'application/json';
      body = JSON.stringify(body);
    }

    const res = await fetch(API_BASE + path, Object.assign({}, options, { headers, body }));

    const isJson = String(res.headers.get('content-type') || '').includes('application/json');
    const payload = isJson ? await res.json().catch(() => ({})) : await res.text().catch(() => '');

    if(!res.ok){
      const msg = (payload && payload.error) ? payload.error : `Request failed (${res.status})`;
      throw new Error(msg);
    }

    return payload;
  }

  async function fetchMe(){
    const r = await api('/api/auth/me');
    return r.caregiver;
  }

  async function fetchPatientMe(){
    const r = await api('/api/patient/me');
    return r.patient;
  }

  function requireLoginOrRedirect(){
    const auth = getAuth();
    if(!auth.loggedIn){
      window.location.href = 'caregiver-login.html';
      return false;
    }
    return true;
  }

  function formatDate(d){
    try{
      const dt = new Date(d);
      if(Number.isNaN(dt.getTime())) return String(d || '');
      return dt.toLocaleDateString(undefined, { year:'numeric', month:'short', day:'2-digit' });
    }catch{ return String(d || ''); }
  }

  function initRegister(){
    const form = $('#caregiverRegisterForm');
    if(!form) return;

    const notice = $('#registerNotice');

    form.addEventListener('submit', async (e) => {
      e.preventDefault();

      const data = Object.fromEntries(new FormData(form).entries());

      const required = ['fullName','phone','aadhaar','experienceYears','email','password'];
      const missing = required.filter(k => !String(data[k] ?? '').trim());
      if(missing.length){
        setNotice(notice, 'Please fill all required fields.', 'bad');
        return;
      }

      if(!/^\d{10}$/.test(String(data.phone))){
        setNotice(notice, 'Phone number must be 10 digits.', 'bad');
        return;
      }

      if(!/^\d{12}$/.test(String(data.aadhaar))){
        setNotice(notice, 'Aadhaar must be 12 digits.', 'bad');
        return;
      }

      const exp = Number(data.experienceYears);
      if(!Number.isFinite(exp) || exp < 0 || exp > 60){
        setNotice(notice, 'Experience must be a valid number (0–60).', 'bad');
        return;
      }

      const profile = {
        fullName: String(data.fullName).trim(),
        phone: String(data.phone).trim(),
        aadhaar: String(data.aadhaar).trim(),
        email: String(data.email).trim(),
        experienceYears: exp,
        specialization: String(data.specialization || 'General Care').trim(),
        city: String(data.city || '').trim(),
        languages: String(data.languages || '').trim(),
        shift: String(data.shift || 'Flexible').trim(),
        regNo: String(data.regNo || '').trim()
      };

      try{
        const r = await api('/api/auth/register', {
          method: 'POST',
          body: Object.assign({}, profile, { password: String(data.password || '').trim() })
        });
        setToken(r.token);

        setNotice(notice, 'Registration complete. Redirecting to visit form…', 'good');
        setTimeout(() => { window.location.href = 'visit-form.html'; }, 650);
      }catch(err){
        setNotice(notice, err.message || 'Registration failed.', 'bad');
      }
    });
  }

  function initCaregiverLogin(){
    const form = $('#caregiverLoginForm');
    if(!form) return;

    const notice = $('#loginNotice');

    form.addEventListener('submit', async (e) => {
      e.preventDefault();

      const data = Object.fromEntries(new FormData(form).entries());

      const email = String(data.email || '').trim();
      const password = String(data.password || '').trim();

      if(!email || !password){
        setNotice(notice, 'Please enter email and password.', 'bad');
        return;
      }

      try{
        const r = await api('/api/auth/login', {
          method: 'POST',
          body: { email, password }
        });

        setToken(r.token);
        setNotice(notice, 'Login successful. Redirecting to visit form…', 'good');
        setTimeout(() => { window.location.href = 'visit-form.html'; }, 650);
      }catch(err){
        setNotice(notice, err.message || 'Login failed.', 'bad');
      }
    });
  }

  function initVisitForm(){
    const form = $('#visitForm');
    if(!form) return;

    const notice = $('#visitNotice');

    const visitVideo = $('#visitVideo');
    const visitCanvas = $('#visitCanvas');
    const visitStartBtn = $('#visitStartCamBtn');
    const visitCaptureBtn = $('#visitCaptureBtn');
    const visitPhotoFile = $('#visitPhotoFile');
    const visitDetectBtn = $('#visitDetectBtn');
    const visitDetectResultEl = $('#visitDetectResult');

    const preExamFile = $('#preExamPhotoFile');
    const preExamDetectBtn = $('#preExamDetectBtn');
    const preExamDetectResultEl = $('#preExamDetectResult');

    let visitStream = null;
    let capturedVisitPhoto = null;

    let proofDetection = null;
    let preExamDetection = null;

    function ensureSecureContextForCamera(){
      if(window.isSecureContext) return true;
      const host = String(window.location && window.location.hostname || '');
      const isLocal = host === 'localhost' || host === '127.0.0.1';
      if(isLocal) return true;
      setNotice(notice, 'Camera requires HTTPS or http://localhost. Open this page via the running server.', 'bad');
      return false;
    }

    function waitForVideoReady(videoEl, timeoutMs){
      return new Promise((resolve) => {
        if(!videoEl) return resolve(false);
        if((videoEl.videoWidth || 0) > 0 && (videoEl.videoHeight || 0) > 0) return resolve(true);

        let done = false;
        const t = setTimeout(() => { if(done) return; done = true; resolve(false); }, timeoutMs || 1500);
        const onReady = () => {
          if(done) return;
          done = true;
          clearTimeout(t);
          videoEl.removeEventListener('loadedmetadata', onReady);
          videoEl.removeEventListener('canplay', onReady);
          resolve(true);
        };
        videoEl.addEventListener('loadedmetadata', onReady);
        videoEl.addEventListener('canplay', onReady);
      });
    }

    const patientStep = $('#patientStep');
    const visitStep = $('#visitStep');
    const patientNameRow = $('#patientNameRow');
    const continueBtn = $('#patientContinueBtn');
    const backBtn = $('#backToPatientBtn');
    const checkedAtDisplay = $('#checkedAtDisplay');

    async function startVisitCamera(){
      if(!ensureSecureContextForCamera()) return;
      if(!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia){
        setNotice(notice, 'Camera not supported on this device/browser.', 'bad');
        return;
      }
      try{
        visitStream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' }, audio: false });
        if(visitVideo){
          visitVideo.srcObject = visitStream;
          await visitVideo.play().catch(() => {});
        }
        setNotice(notice, 'Camera started. Capture the visit photo.', 'good');
      }catch(err){
        setNotice(notice, err && err.message ? err.message : 'Failed to start camera.', 'bad');
      }
    }

    function stopVisitCamera(){
      if(visitStream){
        visitStream.getTracks().forEach(t => t.stop());
        visitStream = null;
      }
      if(visitVideo) visitVideo.srcObject = null;
    }

    async function captureVisitToBlob(){
      if(visitPhotoFile && visitPhotoFile.files && visitPhotoFile.files[0]){
        capturedVisitPhoto = visitPhotoFile.files[0];
        setNotice(notice, 'Photo selected. You can save the visit now.', 'good');
        return;
      }

      if(!visitVideo || !visitCanvas){
        setNotice(notice, 'Camera UI not available on this page.', 'bad');
        return;
      }
      if(!visitStream){
        setNotice(notice, 'Start camera first.', 'bad');
        return;
      }

      const ready = await waitForVideoReady(visitVideo, 2000);
      if(!ready){
        setNotice(notice, 'Camera not ready yet. Wait 1–2 seconds and try capture again.', 'bad');
        return;
      }

      const w = visitVideo.videoWidth || 1280;
      const h = visitVideo.videoHeight || 720;
      visitCanvas.width = w;
      visitCanvas.height = h;
      const ctx = visitCanvas.getContext('2d');
      ctx.drawImage(visitVideo, 0, 0, w, h);

      await new Promise((resolve) => {
        visitCanvas.toBlob((b) => { capturedVisitPhoto = b; resolve(); }, 'image/jpeg', 0.9);
      });

      if(capturedVisitPhoto){
        setNotice(notice, 'Photo captured. You can save the visit now.', 'good');
      }else{
        setNotice(notice, 'Capture failed. Try again.', 'bad');
      }
    }

    async function detectProofPhoto(){
      try{
        const uploadPhoto = capturedVisitPhoto
          ? (capturedVisitPhoto instanceof File ? capturedVisitPhoto : new File([capturedVisitPhoto], 'visit.jpg', { type: 'image/jpeg' }))
          : (visitPhotoFile && visitPhotoFile.files && visitPhotoFile.files[0] ? visitPhotoFile.files[0] : null);

        if(!(uploadPhoto instanceof File)){
          if(visitDetectResultEl) visitDetectResultEl.textContent = 'Please capture or upload the proof photo first.';
          return;
        }

        if(visitDetectResultEl) visitDetectResultEl.textContent = 'Running YOLOv8 detection…';
        const r = await runYoloOnFile(uploadPhoto);
        proofDetection = r;
        if(visitDetectResultEl) visitDetectResultEl.textContent = formatYoloSummary(r);
      }catch(err){
        if(visitDetectResultEl) visitDetectResultEl.textContent = String(err && err.message ? err.message : 'Detection failed');
      }
    }

    async function detectPreExamPhoto(){
      try{
        const file = preExamFile && preExamFile.files && preExamFile.files[0] ? preExamFile.files[0] : null;
        if(!(file instanceof File)){
          if(preExamDetectResultEl) preExamDetectResultEl.textContent = 'Please upload a pre-exam image first.';
          return;
        }
        if(preExamDetectResultEl) preExamDetectResultEl.textContent = 'Running YOLOv8 detection…';
        const r = await runYoloOnFile(file);
        preExamDetection = r;
        if(preExamDetectResultEl) preExamDetectResultEl.textContent = formatYoloSummary(r);
      }catch(err){
        if(preExamDetectResultEl) preExamDetectResultEl.textContent = String(err && err.message ? err.message : 'Detection failed');
      }
    }

    if(visitStartBtn) visitStartBtn.addEventListener('click', startVisitCamera);
    if(visitCaptureBtn) visitCaptureBtn.addEventListener('click', async () => {
      await captureVisitToBlob();
    });
    if(visitPhotoFile) visitPhotoFile.addEventListener('change', () => {
      capturedVisitPhoto = (visitPhotoFile.files && visitPhotoFile.files[0]) ? visitPhotoFile.files[0] : null;
    });

    if(visitDetectBtn) visitDetectBtn.addEventListener('click', detectProofPhoto);
    if(preExamDetectBtn) preExamDetectBtn.addEventListener('click', detectPreExamPhoto);

    if(!getAuth().loggedIn || getRole() !== 'caregiver'){
      setNotice(notice, 'Caregiver login required. Redirecting…', 'bad');
      setTimeout(() => { window.location.href = 'caregiver-login.html'; }, 650);
      return;
    }

    if(visitStep) visitStep.style.display = 'none';
    if(patientNameRow) patientNameRow.style.display = 'none';

    const today = new Date();
    const dateInput = $('#visitDate');
    if(dateInput && !dateInput.value){
      const yyyy = today.getFullYear();
      const mm = String(today.getMonth()+1).padStart(2,'0');
      const dd = String(today.getDate()).padStart(2,'0');
      dateInput.value = `${yyyy}-${mm}-${dd}`;
    }

    const tsEl = $('#timestampNote');
    const checkedAt = new Date().toISOString();
    if(tsEl) tsEl.textContent = `Timestamp (auto): ${checkedAt}`;
    if(checkedAtDisplay) checkedAtDisplay.value = checkedAt;

    const locBtn = $('#getLocationBtn');
    const latEl = $('#lat');
    const lngEl = $('#lng');

    function getFormValue(name){
      const el = form.querySelector(`[name="${name}"]`);
      return el ? String(el.value || '').trim() : '';
    }

    function setFormValue(name, value){
      const el = form.querySelector(`[name="${name}"]`);
      if(el) el.value = value;
    }

    function setReadonly(name, on){
      const el = form.querySelector(`[name="${name}"]`);
      if(el) el.readOnly = !!on;
    }

    function localYmd(d){
      const yyyy = d.getFullYear();
      const mm = String(d.getMonth()+1).padStart(2,'0');
      const dd = String(d.getDate()).padStart(2,'0');
      return `${yyyy}-${mm}-${dd}`;
    }

    function showVisitStep(){
      if(patientStep) patientStep.style.display = 'none';
      if(visitStep) visitStep.style.display = '';

      // Mark this patient as "in process" for today's shift
      try{
        const patientId = getFormValue('patientId');
        if(patientId){
          const key = 'carehub_shift_inprogress_v1';
          const map = safeParse(localStorage.getItem(key), {});
          const day = localYmd(new Date());
          if(!map[day]) map[day] = {};
          map[day][patientId] = { startedAt: Date.now() };
          localStorage.setItem(key, JSON.stringify(map));
        }
      }catch{}

      window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    function showPatientStep(){
      if(visitStep) visitStep.style.display = 'none';
      if(patientStep) patientStep.style.display = '';
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    async function patientContinue(){
      const patientId = getFormValue('patientId');
      const patientPhone = getFormValue('patientPhone');

      if(!patientId || !patientPhone){
        setNotice(notice, 'Enter Patient ID and phone to continue.', 'bad');
        return;
      }
      if(!/^\d{10}$/.test(patientPhone)){
        setNotice(notice, 'Patient phone must be 10 digits.', 'bad');
        return;
      }

      // Try to fetch patient (so caregiver doesn’t re-enter name every time)
      try{
        const r = await api(`/api/patients/lookup?patientId=${encodeURIComponent(patientId)}&patientPhone=${encodeURIComponent(patientPhone)}`);
        const pt = r.patient;
        if(pt && pt.patientName){
          setFormValue('patientName', String(pt.patientName));
          setReadonly('patientName', true);
          if(patientNameRow) patientNameRow.style.display = 'none';
          setNotice(notice, 'Patient verified. Fill visit details now.', 'good');
          showVisitStep();
          return;
        }
      }catch(err){
        const msg = String(err && err.message ? err.message : '');
        // If not found, allow caregiver to enter name once.
        if(/not found/i.test(msg)){
          setReadonly('patientName', false);
          if(patientNameRow) patientNameRow.style.display = '';
          setNotice(notice, 'Patient not found. Enter patient name to create record, then press Continue again.', 'bad');
          return;
        }
        setNotice(notice, msg || 'Failed to verify patient.', 'bad');
        return;
      }

      // If lookup didn’t return a name for some reason, require manual name
      setReadonly('patientName', false);
      if(patientNameRow) patientNameRow.style.display = '';
      setNotice(notice, 'Enter patient name to continue.', 'bad');
    }

    if(continueBtn) continueBtn.addEventListener('click', async () => {
      // If name row is visible, allow proceed when name is filled
      if(patientNameRow && patientNameRow.style.display !== 'none'){
        const name = getFormValue('patientName');
        if(!name){
          setNotice(notice, 'Patient name is required to create a new record.', 'bad');
          return;
        }
        setNotice(notice, 'New patient details captured. Fill visit details now.', 'good');
        showVisitStep();
        return;
      }

      await patientContinue();
    });

    if(backBtn) backBtn.addEventListener('click', showPatientStep);

    async function fillLocation(){
      if(!navigator.geolocation){
        setNotice(notice, 'Geolocation not supported on this device/browser.', 'bad');
        return;
      }

      setNotice(notice, 'Getting GPS location…', 'good');
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          const lat = pos.coords.latitude;
          const lng = pos.coords.longitude;
          if(latEl) latEl.value = String(lat);
          if(lngEl) lngEl.value = String(lng);
          setNotice(notice, 'Location captured. Please fill address too.', 'good');
        },
        (err) => {
          setNotice(notice, err && err.message ? err.message : 'Failed to get location.', 'bad');
        },
        { enableHighAccuracy: true, timeout: 15000, maximumAge: 0 }
      );
    }

    if(locBtn) locBtn.addEventListener('click', fillLocation);

    form.addEventListener('submit', async (e) => {
      e.preventDefault();

      // Ensure user completed patient step first
      if(visitStep && visitStep.style.display === 'none'){
        setNotice(notice, 'Please complete the patient login step first.', 'bad');
        return;
      }

      const fd = new FormData(form);

      const patientName = String(fd.get('patientName') || '').trim();
      const patientId = String(fd.get('patientId') || '').trim();
      const patientPhone = String(fd.get('patientPhone') || '').trim();
      const visitDate = String(fd.get('visitDate') || '').trim();
      const bp = String(fd.get('bp') || '').trim();
      const pulse = String(fd.get('pulse') || '').trim();
      const spo2 = String(fd.get('spo2') || '').trim();
      const tempC = String(fd.get('tempC') || '').trim();
      const findings = String(fd.get('findings') || '').trim();
      const address = String(fd.get('address') || '').trim();
      const lat = String(fd.get('lat') || '').trim();
      const lng = String(fd.get('lng') || '').trim();
      const notes = String(fd.get('notes') || '').trim();
      const photo = fd.get('photo');

      const uploadPhoto = capturedVisitPhoto
        ? (capturedVisitPhoto instanceof File ? capturedVisitPhoto : new File([capturedVisitPhoto], 'visit.jpg', { type: 'image/jpeg' }))
        : photo;

      const required = [patientName, patientId, patientPhone, visitDate, bp, pulse, spo2, tempC, findings, address, lat, lng];
      if(required.some(v => !v)){
        setNotice(notice, 'Please fill all required fields (including GPS + address).', 'bad');
        return;
      }

      if(!/^\d{10}$/.test(patientPhone)){
        setNotice(notice, 'Patient phone must be 10 digits.', 'bad');
        return;
      }

      if(!(uploadPhoto instanceof File) || !uploadPhoto.name){
        setNotice(notice, 'Please capture or upload an image.', 'bad');
        return;
      }

      const checklist = {
        medicationReviewed: !!fd.get('check_medication'),
        woundSkinCheck: !!fd.get('check_wound'),
        fallRiskCheck: !!fd.get('check_fall'),
        hydrationNutrition: !!fd.get('check_hydration'),

        bloodSugarChecked: !!fd.get('check_blood_sugar'),
        respiratoryAssessment: !!fd.get('check_resp'),
        medicationAdministered: !!fd.get('check_med_admin'),
        dressingOrWoundCare: !!fd.get('check_dressing'),
        mobilityExercisesGuided: !!fd.get('check_mobility'),
        hygieneSupport: !!fd.get('check_hygiene'),
        mentalWellbeingCheck: !!fd.get('check_mental'),
        followUpScheduled: !!fd.get('check_followup')
      };

      const vitals = { bp, pulse, spo2, tempC };

      // Build multipart payload expected by backend
      const out = new FormData();
      out.set('patientName', patientName);
      out.set('patientId', patientId);
      out.set('patientPhone', patientPhone);
      out.set('visitDate', visitDate);
      out.set('checkedAt', checkedAt);
      out.set('address', address);
      out.set('lat', lat);
      out.set('lng', lng);
      out.set('findings', findings);
      out.set('vitalsJson', JSON.stringify(vitals));
      out.set('checklistJson', JSON.stringify(checklist));
      if(preExamDetection || proofDetection){
        out.set('detectionJson', JSON.stringify({ preExam: preExamDetection, proof: proofDetection }));
      }
      out.set('notes', notes);
      out.set('photo', uploadPhoto);

      try{
        await api('/api/visits', { method: 'POST', body: out });

        // Remove from "in process" once saved
        try{
          const key = 'carehub_shift_inprogress_v1';
          const map = safeParse(localStorage.getItem(key), {});
          const day = localYmd(new Date());
          if(map[day] && map[day][patientId]){
            delete map[day][patientId];
            localStorage.setItem(key, JSON.stringify(map));
          }
        }catch{}

        setNotice(notice, 'Visit saved to database. Opening dashboard…', 'good');
        setTimeout(() => { window.location.href = 'caregiver.html'; }, 650);
      }catch(err){
        setNotice(notice, err.message || 'Failed to save visit.', 'bad');
      }
    });

    window.addEventListener('beforeunload', stopVisitCamera);
  }

  function initPatientAuth(){
    const form = $('#patientAuthForm');
    if(!form) return;

    const notice = $('#patientAuthNotice');

    form.addEventListener('submit', async (e) => {
      e.preventDefault();

      const data = Object.fromEntries(new FormData(form).entries());
      const patientId = String(data.patientId || '').trim();
      const patientPhone = String(data.patientPhone || '').trim();

      if(!patientId || !patientPhone){
        setNotice(notice, 'Please enter Patient ID and phone.', 'bad');
        return;
      }
      if(!/^\d{10}$/.test(patientPhone)){
        setNotice(notice, 'Phone must be 10 digits.', 'bad');
        return;
      }

      try{
        const r = await api('/api/patient/login', { method: 'POST', body: { patientId, patientPhone } });
        setToken(r.token);
        setNotice(notice, 'Login successful. Opening patient portal…', 'good');
        setTimeout(() => { window.location.href = 'patient.html'; }, 650);
      }catch(err){
        setNotice(notice, err.message || 'Patient login failed.', 'bad');
      }
    });
  }

  function initPatientRegister(){
    const form = $('#patientRegisterForm');
    if(!form) return;

    const notice = $('#patientRegNotice');
    const idBox = $('#patientIdBox');
    const idDisplay = $('#patientIdDisplay');

    const video = $('#regVideo');
    const canvas = $('#regCanvas');
    const startBtn = $('#regStartCamBtn');
    const captureBtn = $('#regCaptureBtn');
    const fileInput = $('#regPhotoFile');
    const detectBtn = $('#regDetectBtn');
    const detectResultEl = $('#regDetectResult');

    let stream = null;
    let capturedBlob = null;

    let regDetection = null;

    async function startCamera(){
      if(!window.isSecureContext){
        setNotice(notice, 'Camera requires HTTPS or http://localhost. Open the page via the server.', 'bad');
        return;
      }
      if(!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia){
        setNotice(notice, 'Camera not supported on this device/browser.', 'bad');
        return;
      }
      try{
        stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user' }, audio: false });
        if(video){
          video.srcObject = stream;
          await video.play().catch(() => {});
        }
        setNotice(notice, 'Camera started. Capture a clear face photo.', 'good');
      }catch(err){
        setNotice(notice, err && err.message ? err.message : 'Failed to start camera.', 'bad');
      }
    }

    function stopCamera(){
      if(stream){
        stream.getTracks().forEach(t => t.stop());
        stream = null;
      }
      if(video) video.srcObject = null;
    }

    async function captureToBlob(){
      if(fileInput && fileInput.files && fileInput.files[0]){
        capturedBlob = fileInput.files[0];
        setNotice(notice, 'Photo selected. You can register now.', 'good');
        return;
      }

      if(!video || !canvas){
        setNotice(notice, 'Camera UI not available.', 'bad');
        return;
      }
      if(!stream){
        setNotice(notice, 'Start camera first.', 'bad');
        return;
      }

      if((video.videoWidth || 0) === 0){
        await new Promise((resolve) => {
          let done = false;
          const t = setTimeout(() => { if(done) return; done = true; resolve(); }, 2000);
          const onReady = () => {
            if(done) return;
            done = true;
            clearTimeout(t);
            video.removeEventListener('loadedmetadata', onReady);
            video.removeEventListener('canplay', onReady);
            resolve();
          };
          video.addEventListener('loadedmetadata', onReady);
          video.addEventListener('canplay', onReady);
        });
      }

      if((video.videoWidth || 0) === 0){
        setNotice(notice, 'Camera not ready yet. Wait 1–2 seconds and try capture again.', 'bad');
        return;
      }

      const w = video.videoWidth || 640;
      const h = video.videoHeight || 480;
      canvas.width = w;
      canvas.height = h;
      const ctx = canvas.getContext('2d');
      ctx.drawImage(video, 0, 0, w, h);

      await new Promise((resolve) => {
        canvas.toBlob((b) => { capturedBlob = b; resolve(); }, 'image/jpeg', 0.9);
      });

      if(capturedBlob){
        setNotice(notice, 'Captured. You can register now.', 'good');
      }else{
        setNotice(notice, 'Capture failed. Try again.', 'bad');
      }
    }

    async function detectRegPhoto(){
      try{
        const file = (capturedBlob instanceof File)
          ? capturedBlob
          : (capturedBlob ? new File([capturedBlob], 'patient.jpg', { type: 'image/jpeg' }) : null);

        if(!(file instanceof File)){
          if(detectResultEl) detectResultEl.textContent = 'Please capture or upload a photo first.';
          return;
        }

        if(detectResultEl) detectResultEl.textContent = 'Running YOLOv8 detection…';
        const r = await runYoloOnFile(file);
        regDetection = r;
        if(detectResultEl) detectResultEl.textContent = formatYoloSummary(r);
      }catch(err){
        if(detectResultEl) detectResultEl.textContent = String(err && err.message ? err.message : 'Detection failed');
      }
    }

    if(startBtn) startBtn.addEventListener('click', startCamera);
    if(captureBtn) captureBtn.addEventListener('click', async () => {
      await captureToBlob();
    });
    if(fileInput) fileInput.addEventListener('change', () => {
      capturedBlob = (fileInput.files && fileInput.files[0]) ? fileInput.files[0] : null;
    });
    if(detectBtn) detectBtn.addEventListener('click', detectRegPhoto);

    form.addEventListener('submit', async (e) => {
      e.preventDefault();

      const data = Object.fromEntries(new FormData(form).entries());
      const patientName = String(data.patientName || '').trim();
      const patientPhone = String(data.patientPhone || '').trim();
      const aadhaar = String(data.aadhaar || '').trim();

      if(!patientName || !patientPhone || !aadhaar){
        setNotice(notice, 'Please fill all required fields.', 'bad');
        return;
      }
      if(!/^\d{10}$/.test(patientPhone)){
        setNotice(notice, 'Mobile must be 10 digits.', 'bad');
        return;
      }
      if(!/^\d{12}$/.test(aadhaar)){
        setNotice(notice, 'Aadhaar must be 12 digits.', 'bad');
        return;
      }
      if(!capturedBlob){
        setNotice(notice, 'Please capture or upload a photo.', 'bad');
        return;
      }

      try{
        const fd = new FormData();
        fd.set('patientName', patientName);
        fd.set('patientPhone', patientPhone);
        fd.set('aadhaar', aadhaar);
        fd.set('photo', capturedBlob, 'patient.jpg');

        const r = await api('/api/patient/register', { method: 'POST', body: fd });
        setToken(r.token);
        setNotice(notice, 'Registration successful.', 'good');

        if(idBox){
          idBox.hidden = false;
          idBox.textContent = `Your Patient ID is: ${r.patient.patientId}. Save it for future login.`;
        }

        if(idDisplay){
          idDisplay.value = String(r.patient.patientId || '');
        }

        stopCamera();
      }catch(err){
        setNotice(notice, err.message || 'Registration failed.', 'bad');
      }
    });

    window.addEventListener('beforeunload', stopCamera);
  }

  function initPatientPortal(){
    const root = document.body;
    if(!root || !root.dataset || root.dataset.page !== 'patient') return;

    const notice = $('#ptNotice');

    if(!getAuth().loggedIn || getRole() !== 'patient'){
      setNotice(notice, 'Patient login required. Redirecting…', 'bad');
      setTimeout(() => { window.location.href = 'patient-login.html'; }, 650);
      return;
    }

    const logoutBtn = $('#patientLogoutBtn');
    if(logoutBtn){
      logoutBtn.addEventListener('click', () => {
        clearToken();
        window.location.href = 'patient-login.html';
      });
    }

    (async () => {
      let me;
      try{
        me = await fetchPatientMe();
      }catch{
        clearToken();
        window.location.href = 'patient-login.html';
        return;
      }

      const title = $('#ptTitle');
      const sub = $('#ptSub');
      if(title) title.textContent = `Welcome, ${me.patientName}`;
      if(sub) sub.textContent = `Patient ID: ${me.patientId}`;

      const tbody = $('#patientVisitsTbody');
      if(!tbody) return;

      tbody.innerHTML = '';
      let visits = [];
      try{
        const r = await api('/api/patient/visits?limit=20');
        visits = Array.isArray(r.visits) ? r.visits : [];
      }catch(err){
        setNotice(notice, err.message || 'Failed to load visits.', 'bad');
        visits = [];
      }

      if(!visits.length){
        tbody.innerHTML = `<tr><td colspan="5" style="color: rgba(233,238,255,.60);">No visits found yet.</td></tr>`;
      }else{
        function summarizeHygiene(checklist){
          const c = checklist || {};
          const yesNo = (v) => (v ? 'Yes' : 'No');
          const hygiene = yesNo(!!c.hygieneSupport);
          const woundCare = yesNo(!!c.dressingOrWoundCare);
          const woundCheck = yesNo(!!c.woundSkinCheck);
          return `Hygiene report: Hygiene/bathing support: ${hygiene} • Wound/skin check: ${woundCheck} • Dressing/wound care: ${woundCare}`;
        }

        for(const v of visits){
          const vitals = safeParse(v.vitalsJson, {});
          const vit = `BP: ${vitals.bp || '—'} | Pulse: ${vitals.pulse || '—'} | SpO₂: ${vitals.spo2 || '—'} | Temp: ${vitals.tempC || '—'}`;

          const checklist = safeParse(v.checklistJson, {});
          const detection = safeParse(v.detectionJson, null);
          const detectionSummary = detection && detection.proof ? formatYoloSummary(detection.proof) : (detection ? formatYoloSummary(detection) : 'YOLOv8: no detection saved.');

          const tr = document.createElement('tr');
          const safeCheckedAt = String(v.checkedAt || '').replace('T',' ').replace('Z','');
          const safeCaregiverName = (v.caregiverName || 'Caregiver').replace(/</g,'&lt;');
          const safeCaregiverPhone = (v.caregiverPhone || '').replace(/</g,'&lt;');
          const safeFindings = (v.findings || '').replace(/</g,'&lt;');
          const safeLoc = (v.locationAddress || '—').replace(/</g,'&lt;');
          const safeCoords = `${(v.locationLat || '—')}, ${(v.locationLng || '—')}`;

          const imgHtml = v.imagePath
            ? `
              <div class="visit-photo-wrap">
                <img class="visit-photo" src="${v.imagePath}" alt="Visit photo" loading="lazy" />
                <div class="stack" style="margin-top:10px;">
                  <a class="pill" href="${v.imagePath}" target="_blank" rel="noopener">Open</a>
                  <button class="btn" type="button" data-action="detect" data-img="${v.imagePath}">Run detection</button>
                </div>
                <div class="sub" style="margin-top:10px;" data-detect-out>${detectionSummary.replace(/</g,'&lt;')}</div>
                <div class="sub" style="margin-top:6px;" data-hygiene-out>${summarizeHygiene(checklist).replace(/</g,'&lt;')}</div>
              </div>
            `
            : '—';

          tr.innerHTML = `
            <td>${formatDate(v.visitDate)}<div style="opacity:.7; font-size:12px; margin-top:4px;">${safeCheckedAt}</div></td>
            <td>${safeCaregiverName}<div style="opacity:.7; font-size:12px; margin-top:4px;">${safeCaregiverPhone}</div></td>
            <td>${vit.replace(/</g,'&lt;')}<div style="opacity:.75; font-size:12px; margin-top:6px;">${safeFindings}</div></td>
            <td>${safeLoc}<div style="opacity:.7; font-size:12px; margin-top:4px;">${safeCoords}</div></td>
            <td>${imgHtml}</td>
          `;

          const img = tr.querySelector('img.visit-photo');
          if(img){
            img.addEventListener('error', () => {
              const wrap = tr.querySelector('.visit-photo-wrap');
              if(wrap) wrap.innerHTML = '<div class="sub">Photo could not be loaded.</div>';
            });
          }

          const detectBtn = tr.querySelector('button[data-action="detect"]');
          if(detectBtn){
            detectBtn.addEventListener('click', async () => {
              const imgUrl = String(detectBtn.getAttribute('data-img') || '').trim();
              const outEl = tr.querySelector('[data-detect-out]');
              if(!imgUrl) return;
              if(outEl) outEl.textContent = 'Running YOLOv8 detection…';

              try{
                const resp = await fetch(imgUrl);
                const blob = await resp.blob();
                const file = new File([blob], 'visit.jpg', { type: blob.type || 'image/jpeg' });
                const r = await runYoloOnFile(file);
                if(outEl) outEl.textContent = formatYoloSummary(r);
              }catch(err){
                if(outEl) outEl.textContent = String(err && err.message ? err.message : 'Detection failed');
              }
            });
          }

          tbody.appendChild(tr);
        }
      }

      // Reminders: medicines + tests
      const remindersNotice = $('#remindersNotice');
      const enableBtn = $('#enableNotificationsBtn');
      const medForm = $('#medReminderForm');
      const testForm = $('#testReminderForm');
      const medTbody = $('#medRemindersTbody');
      const testTbody = $('#testRemindersTbody');

      const NOTIF_KEY = 'carehub_reminder_notified_v1';
      let timers = [];

      function clearTimers(){
        for(const t of timers) clearTimeout(t);
        timers = [];
      }

      function loadNotified(){
        return safeParse(localStorage.getItem(NOTIF_KEY), {});
      }

      function saveNotified(map){
        try{ localStorage.setItem(NOTIF_KEY, JSON.stringify(map || {})); }catch{}
      }

      function canNotify(){
        return typeof window.Notification !== 'undefined';
      }

      function isSecureForNotifications(){
        if(window.isSecureContext) return true;
        const host = String(window.location && window.location.hostname || '');
        return host === 'localhost' || host === '127.0.0.1';
      }

      async function ensureNotifyPermission(){
        if(!canNotify()){
          setNotice(remindersNotice, 'Notifications are not supported in this browser.', 'bad');
          return false;
        }

        if(!isSecureForNotifications()){
          setNotice(remindersNotice, 'Notifications require HTTPS or http://localhost.', 'bad');
          return false;
        }

        if(Notification.permission === 'granted') return true;
        if(Notification.permission === 'denied'){
          setNotice(remindersNotice, 'Notifications are blocked. Enable them in browser settings.', 'bad');
          return false;
        }
        const p = await Notification.requestPermission();
        if(p === 'granted'){
          setNotice(remindersNotice, 'Notifications enabled.', 'good');
          return true;
        }
        setNotice(remindersNotice, 'Notification permission not granted.', 'bad');
        return false;
      }

      function sendReminderNotification(title, body){
        if(canNotify() && Notification.permission === 'granted'){
          try{ new Notification(title, { body }); }catch{}
        }
        // Always show an in-page notice too
        setNotice(remindersNotice, `${title}: ${body}`, 'good');
      }

      function toLocalDateKey(d){
        const yyyy = d.getFullYear();
        const mm = String(d.getMonth()+1).padStart(2,'0');
        const dd = String(d.getDate()).padStart(2,'0');
        return `${yyyy}-${mm}-${dd}`;
      }

      function scheduleMedication(m){
        if(!m || !m.enabled) return;
        const time = String(m.timeOfDay || '').trim();
        if(!/^\d{2}:\d{2}$/.test(time)) return;

        const [hh, mm] = time.split(':').map(n => Number(n));
        const now = new Date();
        let next = new Date(now);
        next.setHours(hh, mm, 0, 0);
        if(next.getTime() <= now.getTime() + 15000){
          next = new Date(next.getTime() + 24*60*60*1000);
        }

        const delay = Math.max(0, next.getTime() - now.getTime());
        const t = setTimeout(() => {
          const map = loadNotified();
          const key = `med:${m.id}:${toLocalDateKey(new Date())}:${time}`;
          if(map[key]) return;
          map[key] = Date.now();
          saveNotified(map);

          sendReminderNotification('Medicine time', `${m.medName} (${m.timeOfDay})`);
          // Reschedule next day
          scheduleMedication(m);
        }, delay);
        timers.push(t);
      }

      function parseDateTimeLocal(value){
        // value: YYYY-MM-DDTHH:MM (from <input type="datetime-local">)
        const s = String(value || '').trim();
        const m = s.match(/^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})$/);
        if(!m) return null;
        const yyyy = Number(m[1]);
        const mm = Number(m[2]);
        const dd = Number(m[3]);
        const hh = Number(m[4]);
        const mi = Number(m[5]);
        const d = new Date(yyyy, mm - 1, dd, hh, mi, 0, 0);
        return Number.isNaN(d.getTime()) ? null : d;
      }

      // Ticker (fallback): checks every 20s so reminders still fire even if timers are throttled.
      let tickHandle = null;
      let currentMeds = [];
      let currentTests = [];

      function stopTicker(){
        if(tickHandle){
          clearInterval(tickHandle);
          tickHandle = null;
        }
      }

      function startTicker(){
        stopTicker();
        tickHandle = setInterval(() => {
          const now = new Date();
          const map = loadNotified();

          // Medication: trigger if current time is within 60s after scheduled time
          for(const m of currentMeds){
            if(!m || !m.enabled) continue;
            const time = String(m.timeOfDay || '').trim();
            if(!/^\d{2}:\d{2}$/.test(time)) continue;
            const [hh, mi] = time.split(':').map(Number);
            const due = new Date(now);
            due.setHours(hh, mi, 0, 0);

            const diffMs = now.getTime() - due.getTime();
            if(diffMs < 0 || diffMs > 60 * 1000) continue;

            const key = `med:${m.id}:${toLocalDateKey(now)}:${time}`;
            if(map[key]) continue;
            map[key] = Date.now();
            saveNotified(map);
            sendReminderNotification('Medicine time', `${m.medName} (${m.timeOfDay})`);
          }

          // Tests: trigger if within 60s after dueAt
          for(const t of currentTests){
            if(!t || !t.enabled) continue;
            const due = new Date(String(t.dueAt || ''));
            if(!Number.isFinite(due.getTime())) continue;
            const diffMs = now.getTime() - due.getTime();
            if(diffMs < 0 || diffMs > 60 * 1000) continue;

            const key = `test:${t.id}:${String(t.dueAt || '')}`;
            if(map[key]) continue;
            map[key] = Date.now();
            saveNotified(map);
            sendReminderNotification('Test reminder', `${t.testName} due now`);
          }
        }, 20000);
      }

      function scheduleTest(tst){
        if(!tst || !tst.enabled) return;
        const due = new Date(String(tst.dueAt || ''));
        if(!Number.isFinite(due.getTime())) return;
        const now = new Date();
        if(due.getTime() <= now.getTime()) return;

        const delay = Math.max(0, due.getTime() - now.getTime());
        const t = setTimeout(() => {
          const map = loadNotified();
          const key = `test:${tst.id}:${String(tst.dueAt || '')}`;
          if(map[key]) return;
          map[key] = Date.now();
          saveNotified(map);

          sendReminderNotification('Test reminder', `${tst.testName} due now`);
        }, delay);
        timers.push(t);
      }

      function fmtDue(dueAt){
        try{
          const d = new Date(String(dueAt || ''));
          if(Number.isNaN(d.getTime())) return String(dueAt || '—');
          return d.toLocaleString();
        }catch{ return String(dueAt || '—'); }
      }

      function renderReminders(meds, tests){
        if(medTbody){
          medTbody.innerHTML = '';
          if(!meds.length){
            medTbody.innerHTML = `<tr><td colspan="4" style="color: rgba(233,238,255,.60);">No medicine reminders yet.</td></tr>`;
          }else{
            for(const m of meds){
              const tr = document.createElement('tr');
              tr.innerHTML = `
                <td>${String(m.medName || '').replace(/</g,'&lt;')}</td>
                <td>${String(m.timeOfDay || '').replace(/</g,'&lt;')}</td>
                <td>${String(m.notes || '—').replace(/</g,'&lt;')}</td>
                <td><button class="btn btn-ghost" type="button" data-del-med="${m.id}">Delete</button></td>
              `;
              medTbody.appendChild(tr);
            }
          }
        }

        if(testTbody){
          testTbody.innerHTML = '';
          if(!tests.length){
            testTbody.innerHTML = `<tr><td colspan="4" style="color: rgba(233,238,255,.60);">No test reminders yet.</td></tr>`;
          }else{
            for(const t of tests){
              const tr = document.createElement('tr');
              tr.innerHTML = `
                <td>${String(t.testName || '').replace(/</g,'&lt;')}</td>
                <td>${fmtDue(t.dueAt).replace(/</g,'&lt;')}</td>
                <td>${String(t.notes || '—').replace(/</g,'&lt;')}</td>
                <td><button class="btn btn-ghost" type="button" data-del-test="${t.id}">Delete</button></td>
              `;
              testTbody.appendChild(tr);
            }
          }
        }
      }

      async function loadReminders(){
        clearTimers();
        let medications = [];
        let tests = [];
        try{
          const r = await api('/api/patient/reminders');
          medications = Array.isArray(r.medications) ? r.medications : [];
          tests = Array.isArray(r.tests) ? r.tests : [];
          setNotice(remindersNotice, '', '');
        }catch(err){
          setNotice(remindersNotice, err.message || 'Failed to load reminders.', 'bad');
        }

        renderReminders(medications, tests);

        currentMeds = medications;
        currentTests = tests;

        // Schedule notifications (best-effort)
        for(const m of medications) scheduleMedication(m);
        for(const t of tests) scheduleTest(t);

        startTicker();
      }

      if(enableBtn){
        enableBtn.addEventListener('click', async () => {
          await ensureNotifyPermission();
        });
      }

      if(medForm){
        medForm.addEventListener('submit', async (e) => {
          e.preventDefault();
          const fd = new FormData(medForm);
          const medName = String(fd.get('medName') || '').trim();
          const timeOfDay = String(fd.get('timeOfDay') || '').trim();
          const notes = String(fd.get('notes') || '').trim();
          if(!medName || !timeOfDay){
            setNotice(remindersNotice, 'Medicine name and time are required.', 'bad');
            return;
          }
          try{
            await api('/api/patient/reminders/medications', { method: 'POST', body: { medName, timeOfDay, notes } });
            medForm.reset();
            setNotice(remindersNotice, 'Medicine reminder added.', 'good');
            await loadReminders();
          }catch(err){
            setNotice(remindersNotice, err.message || 'Failed to add medicine reminder.', 'bad');
          }
        });
      }

      if(testForm){
        testForm.addEventListener('submit', async (e) => {
          e.preventDefault();
          const fd = new FormData(testForm);
          const testName = String(fd.get('testName') || '').trim();
          const dueAtLocal = String(fd.get('dueAt') || '').trim();
          const notes = String(fd.get('notes') || '').trim();
          if(!testName || !dueAtLocal){
            setNotice(remindersNotice, 'Test name and due date/time are required.', 'bad');
            return;
          }
          const dueAt = parseDateTimeLocal(dueAtLocal);
          if(!dueAt){
            setNotice(remindersNotice, 'Invalid due date/time.', 'bad');
            return;
          }
          try{
            await api('/api/patient/reminders/tests', { method: 'POST', body: { testName, dueAt: dueAt.toISOString(), notes } });
            testForm.reset();
            setNotice(remindersNotice, 'Test reminder added.', 'good');
            await loadReminders();
          }catch(err){
            setNotice(remindersNotice, err.message || 'Failed to add test reminder.', 'bad');
          }
        });
      }

      // Delegate delete buttons
      document.addEventListener('click', async (e) => {
        const btn = e.target && e.target.closest ? e.target.closest('[data-del-med],[data-del-test]') : null;
        if(!btn) return;

        const medId = btn.getAttribute('data-del-med');
        const testId = btn.getAttribute('data-del-test');
        try{
          if(medId){
            await api(`/api/patient/reminders/medications/${encodeURIComponent(medId)}`, { method: 'DELETE' });
            setNotice(remindersNotice, 'Medicine reminder deleted.', 'good');
          }else if(testId){
            await api(`/api/patient/reminders/tests/${encodeURIComponent(testId)}`, { method: 'DELETE' });
            setNotice(remindersNotice, 'Test reminder deleted.', 'good');
          }
          await loadReminders();
        }catch(err){
          setNotice(remindersNotice, err.message || 'Delete failed.', 'bad');
        }
      }, { passive: true });

      await loadReminders();

      window.addEventListener('beforeunload', () => {
        clearTimers();
        stopTicker();
      });
    })();
  }

  function initDashboard(){
    const root = document.body;
    if(!root || !root.dataset || root.dataset.page !== 'dashboard') return;

    if(!requireLoginOrRedirect()) return;
    if(getRole() !== 'caregiver'){
      clearToken();
      window.location.href = 'caregiver-login.html';
      return;
    }

    (async () => {
      let profile;
      try{
        profile = await fetchMe();
      }catch{
        clearToken();
        window.location.href = 'caregiver-login.html';
        return;
      }

      const map = {
        '#cgName': profile.full_name || 'Caregiver',
        '#cgRole': profile.specialization || 'General Care',
        '#cgEmail': profile.email || '—',
        '#cgPhone': profile.phone || '—',
        '#cgAadhaar': profile.aadhaar || '—',
        '#cgExp': `${Number(profile.experience_years || 0)} yrs`,
        '#cgCity': profile.city || '—',
        '#cgLang': profile.languages || '—',
        '#cgShift': profile.shift || '—'
      };

      for(const [sel, val] of Object.entries(map)){
        const el = $(sel);
        if(el) el.textContent = val;
      }

      let visits = [];
      try{
        const r = await api('/api/visits?limit=50');
        visits = Array.isArray(r.visits) ? r.visits : [];
      }catch{
        visits = [];
      }

      // Shift task chart (today): planned vs completed/in-process/not completed
      const arcDone = $('#taskArcCompleted');
      const arcProg = $('#taskArcInProgress');
      const arcTodo = $('#taskArcNotCompleted');
      const pctEl = $('#taskPct');
      const metaEl = $('#taskMeta');
      const breakdownEl = $('#taskBreakdown');
      const hintEl = $('#taskHint');
      const planInput = $('#shiftTotalTasks');
      const completedInput = $('#shiftCompletedTasks');
      const patientFilterInput = $('#taskPatientIdFilter');
      const savePlanBtn = $('#saveShiftPlanBtn');
      const applyFilterBtn = $('#applyTaskFilterBtn');
      const resetPlanBtn = $('#resetShiftPlanBtn');

      function localYmd(d){
        const yyyy = d.getFullYear();
        const mm = String(d.getMonth()+1).padStart(2,'0');
        const dd = String(d.getDate()).padStart(2,'0');
        return `${yyyy}-${mm}-${dd}`;
      }

      const today = localYmd(new Date());
      const filterKey = `carehub_task_filter_v1:${String(profile.email || 'cg')}:${today}`;
      const inProgKey = 'carehub_shift_inprogress_v1';

      function completedKey(scope){
        const s = String(scope || 'all');
        return `carehub_shift_completed_v1:${String(profile.email || 'cg')}:${today}:${s}`;
      }

      function loadCompletedOverride(scope){
        const raw = String(localStorage.getItem(completedKey(scope)) || '').trim();
        if(raw === '') return null;
        const n = Number(raw);
        if(!Number.isFinite(n) || n < 0) return null;
        return Math.floor(n);
      }

      function saveCompletedOverride(scope, n){
        const v = Math.max(0, Math.floor(Number(n) || 0));
        localStorage.setItem(completedKey(scope), String(v));
      }

      function clearCompletedOverride(scope){
        localStorage.removeItem(completedKey(scope));
      }

      function loadPatientFilter(){
        const v = String(localStorage.getItem(filterKey) || '').trim();
        return v;
      }

      function savePatientFilter(patientId){
        const v = String(patientId || '').trim();
        if(!v) localStorage.removeItem(filterKey);
        else localStorage.setItem(filterKey, v);
      }

      // Total tasks is fixed to the checklist size (12)
      function loadPlan(){
        return TASK_KEYS.length;
      }

      function savePlan(){
        // No-op: total is fixed
      }

      function loadInProgressCount(patientFilter){
        const map = safeParse(localStorage.getItem(inProgKey), {});
        const dayMap = map && map[today] ? map[today] : {};
        if(!dayMap) return 0;
        if(patientFilter) return dayMap[patientFilter] ? 1 : 0;
        return Object.keys(dayMap).length;
      }

      const TASK_KEYS = [
        'medicationReviewed',
        'woundSkinCheck',
        'fallRiskCheck',
        'hydrationNutrition',
        'bloodSugarChecked',
        'respiratoryAssessment',
        'medicationAdministered',
        'dressingOrWoundCare',
        'mobilityExercisesGuided',
        'hygieneSupport',
        'mentalWellbeingCheck',
        'followUpScheduled'
      ];

      function countCompletedTasksFromVisits(rows, patientFilter){
        let done = 0;
        for(const v of rows){
          if(String(v.visitDate || '').trim() !== today) continue;
          if(patientFilter && String(v.patientId || '').trim() !== patientFilter) continue;
          const checklist = safeParse(v.checklistJson, {});
          for(const key of TASK_KEYS){
            if(!!checklist[key]) done += 1;
          }
        }
        return done;
      }

      function setArc(el, pct, offset){
        if(!el) return;
        const p = Math.max(0, Math.min(100, pct));
        el.setAttribute('stroke-dasharray', `${p}, ${100 - p}`);
        el.setAttribute('stroke-dashoffset', String(-offset));
      }

      function renderShiftChart(){
        const patientFilter = loadPatientFilter();
        if(patientFilterInput && patientFilterInput.value !== patientFilter) patientFilterInput.value = patientFilter;

        const scope = patientFilter || 'all';

        const planned = loadPlan();
        if(planInput) planInput.value = String(planned);

        // Completed tasks defaults to 0 (user-editable). If an override exists, use it.
        const completedOverride = loadCompletedOverride(scope);
        const completed = (completedOverride === null) ? 0 : completedOverride;
        if(completedInput){
          const current = String(completedInput.value || '').trim();
          if(completedOverride !== null) {
            completedInput.value = String(completed);
          } else if(current === '') {
            completedInput.value = '0';
          }
        }
        const inProgressPatients = loadInProgressCount(patientFilter);
        const inProgress = inProgressPatients * TASK_KEYS.length;

        const total = Math.max(planned, 0);
        const notCompleted = Math.max(0, total - completed - inProgress);

        const donePct = total ? (completed / total) * 100 : 0;
        const progPct = total ? (inProgress / total) * 100 : 0;
        const todoPct = total ? (notCompleted / total) * 100 : 0;

        // Stack segments in order: done -> in progress -> not completed
        const doneClamped = Math.max(0, Math.min(100, donePct));
        const progClamped = Math.max(0, Math.min(100 - doneClamped, progPct));
        const todoClamped = Math.max(0, Math.min(100 - doneClamped - progClamped, todoPct));

        setArc(arcDone, doneClamped, 0);
        setArc(arcProg, progClamped, doneClamped);
        setArc(arcTodo, todoClamped, doneClamped + progClamped);

        const pct = total ? Math.round((completed / total) * 100) : 0;
        if(pctEl) pctEl.textContent = `${pct}%`;
        if(metaEl) metaEl.textContent = `${completed} / ${total} tasks completed`;
        if(breakdownEl) breakdownEl.textContent = `Completed: ${completed} • In process: ${inProgress} • Not completed: ${notCompleted}`;

        if(hintEl){
          hintEl.textContent = patientFilter
            ? `Patient ${patientFilter}: total tasks fixed at ${total}. In process counts started visit (×${TASK_KEYS.length} tasks).`
            : `Total tasks fixed at ${total}. In process counts started visits (×${TASK_KEYS.length} tasks).`;
        }
      }

      if(savePlanBtn){
        savePlanBtn.addEventListener('click', () => {
          savePlan();
          const patientFilter = loadPatientFilter();
          const scope = patientFilter || 'all';
          if(completedInput){
            const raw = String(completedInput.value || '').trim();
            if(raw === '') clearCompletedOverride(scope);
            else saveCompletedOverride(scope, raw);
          }
          renderShiftChart();
        });
      }

      if(completedInput){
        completedInput.addEventListener('change', () => {
          const patientFilter = loadPatientFilter();
          const scope = patientFilter || 'all';
          const raw = String(completedInput.value || '').trim();
          if(raw === '') {
            clearCompletedOverride(scope);
            completedInput.value = '0';
          }
          else saveCompletedOverride(scope, raw);
          renderShiftChart();
        });
      }

      if(applyFilterBtn){
        applyFilterBtn.addEventListener('click', () => {
          savePatientFilter(patientFilterInput ? patientFilterInput.value : '');
          renderShiftChart();
        });
      }

      if(resetPlanBtn){
        resetPlanBtn.addEventListener('click', () => {
          localStorage.removeItem(filterKey);
          if(planInput) planInput.value = String(TASK_KEYS.length);
          if(patientFilterInput) patientFilterInput.value = '';
          if(completedInput) completedInput.value = '0';
          clearCompletedOverride('all');
          renderShiftChart();
        });
      }

      renderShiftChart();

      const tableBody = $('#visitsTbody');
      if(tableBody){
        const patientPhotoCache = new Map();

        async function fetchPatientPhotoUrl(patientId){
          const pid = String(patientId || '').trim();
          if(!pid) return null;
          if(patientPhotoCache.has(pid)) return patientPhotoCache.get(pid);

          const token = getToken();
          if(!token) {
            patientPhotoCache.set(pid, null);
            return null;
          }

          try{
            const res = await fetch(`/api/patients/photo?patientId=${encodeURIComponent(pid)}`, {
              headers: { Authorization: `Bearer ${token}` }
            });
            if(!res.ok){
              patientPhotoCache.set(pid, null);
              return null;
            }
            const blob = await res.blob();
            const url = URL.createObjectURL(blob);
            patientPhotoCache.set(pid, url);
            return url;
          }catch{
            patientPhotoCache.set(pid, null);
            return null;
          }
        }

        tableBody.innerHTML = '';
        if(!visits.length){
          tableBody.innerHTML = `<tr><td colspan="6" style="color: rgba(233,238,255,.60);">No visits saved yet. Add today\'s patient from “Patient login”.</td></tr>`;
        }else{
          for(const v of visits.slice(0, 10)){
            const tr = document.createElement('tr');
            tr.innerHTML = `
              <td>${v.patientName}</td>
              <td><div class="patient-thumb" data-pid="${String(v.patientId || '').replace(/</g,'&lt;')}">Loading…</div></td>
              <td>${v.patientId}</td>
              <td>${v.patientPhone}</td>
              <td>${formatDate(v.visitDate)}</td>
              <td>${(v.notes || '—').replace(/</g,'&lt;')}</td>
            `;
            tableBody.appendChild(tr);

            const holder = tr.querySelector('.patient-thumb');
            const pid = String(v.patientId || '').trim();
            if(holder && pid){
              fetchPatientPhotoUrl(pid).then((url) => {
                if(!holder) return;
                if(!url){
                  holder.textContent = '—';
                  return;
                }
                holder.textContent = '';
                const img = document.createElement('img');
                img.className = 'patient-thumb-img';
                img.alt = 'Patient photo';
                img.loading = 'lazy';
                img.src = url;
                holder.appendChild(img);
              });
            }
          }
        }
      }
    })();

    const logoutBtn = $('#logoutBtn');
    if(logoutBtn){
      logoutBtn.addEventListener('click', () => {
        clearToken();
        window.location.href = 'caregiver-login.html';
      });
    }

    // Chatbot frontend-only
    const chatForm = $('#chatForm');
    const chatInput = $('#chatInput');
    const chatLog = $('#chatLog');

    // AI visit Q&A (latest visit)
    const aiStartVisitQaBtn = $('#aiStartVisitQaBtn');
    const aiEvaluateVisitQaBtn = $('#aiEvaluateVisitQaBtn');
    const aiQaQuestions = $('#aiQaQuestions');
    const aiQaNotice = $('#aiQaNotice');

    const aiState = {
      visitContext: null,
      questions: null,
      photoBlob: null,
      photoMime: null
    };

    function addMsg(text, who){
      if(!chatLog) return;
      const div = document.createElement('div');
      div.className = `msg ${who}`;
      div.textContent = text;
      chatLog.appendChild(div);
      chatLog.scrollTop = chatLog.scrollHeight;
    }

    function botPlaceholder(){
      addMsg('AI assistant ready. If you see an error, set OPENAI_API_KEY in .env.', 'bot');
      addMsg('Try: “Summarize today’s visit notes” or run “AI visit Q&A”.', 'bot');
    }

    if(chatLog && !chatLog.dataset.inited){
      chatLog.dataset.inited = '1';
      botPlaceholder();
    }

    async function aiChat(userText){
      // Keep last few messages for context
      const history = [];
      if(chatLog){
        const nodes = Array.from(chatLog.querySelectorAll('.msg'));
        for(const n of nodes.slice(-10)){
          const who = n.classList.contains('user') ? 'user' : 'assistant';
          history.push({ role: who, content: String(n.textContent || '') });
        }
      }
      history.push({ role: 'user', content: String(userText || '') });

      const r = await api('/api/ai/chat', {
        method: 'POST',
        body: { messages: history }
      });
      return String(r.message || '').trim();
    }

    function setAiQaNotice(text, kind){
      if(!aiQaNotice) return;
      aiQaNotice.textContent = text;
      aiQaNotice.style.color = kind === 'bad' ? 'rgba(255,140,140,.95)'
        : kind === 'good' ? 'rgba(140,255,190,.95)'
        : 'rgba(233,238,255,.75)';
    }

    function renderAiQuestions(questions){
      if(!aiQaQuestions) return;
      aiQaQuestions.innerHTML = '';
      if(!Array.isArray(questions) || !questions.length){
        aiQaQuestions.innerHTML = '<div class="sub">No questions returned.</div>';
        return;
      }

      for(const q of questions){
        const id = String(q.id || '').trim() || `q_${Math.random().toString(16).slice(2)}`;
        const question = String(q.question || '').trim();
        const expected = String(q.expected || '').trim();
        const status = String(q.status || 'not_completed');

        const wrap = document.createElement('div');
        wrap.className = 'notice';
        wrap.style.marginTop = '10px';

        wrap.innerHTML = `
          <div style="display:flex; justify-content:space-between; gap:10px;">
            <div style="font-weight:700;">${question.replace(/</g,'&lt;')}</div>
            <div class="badge" style="white-space:nowrap;">${status.replace(/</g,'&lt;')}</div>
          </div>
          <div class="sub" style="margin-top:6px;">Expected: ${expected.replace(/</g,'&lt;')}</div>
          <div style="margin-top:10px;">
            <div class="label">Answer</div>
            <input class="input" data-aiq="${id.replace(/"/g,'&quot;')}" placeholder="Type your answer…" />
          </div>
        `;

        aiQaQuestions.appendChild(wrap);
      }
    }

    async function fetchLatestVisitWithPhoto(){
      const r = await api('/api/visits?limit=1');
      const v = Array.isArray(r.visits) && r.visits[0] ? r.visits[0] : null;
      if(!v) throw new Error('No visits found yet. Record a visit first.');

      const visitContext = {
        patientName: v.patientName,
        patientId: v.patientId,
        patientPhone: v.patientPhone,
        visitDate: v.visitDate,
        checkedAt: v.checkedAt,
        location: { lat: v.locationLat, lng: v.locationLng, address: v.locationAddress },
        vitals: safeParse(v.vitalsJson, {}),
        checklist: safeParse(v.checklistJson, {}),
        findings: v.findings,
        notes: v.notes || ''
      };

      let photoBlob = null;
      let photoMime = null;
      if(v.imagePath){
        const resp = await fetch(String(v.imagePath));
        if(resp.ok){
          photoMime = String(resp.headers.get('content-type') || 'image/jpeg');
          photoBlob = await resp.blob();
        }
      }

      return { visitContext, photoBlob, photoMime };
    }

    async function startAiVisitQa(){
      setAiQaNotice('Starting AI Q&A…', '');
      if(aiEvaluateVisitQaBtn) aiEvaluateVisitQaBtn.disabled = true;

      const { visitContext, photoBlob, photoMime } = await fetchLatestVisitWithPhoto();

      const fd = new FormData();
      fd.set('visitContext', JSON.stringify(visitContext));
      if(photoBlob){
        fd.set('photo', photoBlob, 'visit.jpg');
      }

      const r = await api('/api/ai/visit-assistant/start', { method: 'POST', body: fd });

      aiState.visitContext = visitContext;
      aiState.questions = Array.isArray(r.questions) ? r.questions : [];
      aiState.photoBlob = photoBlob;
      aiState.photoMime = photoMime;

      if(r.imageInsights && r.imageInsights.summary){
        addMsg(`Image: ${String(r.imageInsights.summary)}`, 'bot');
      }
      addMsg('AI Q&A ready — answer the questions below, then click “Evaluate answers”.', 'bot');

      renderAiQuestions(aiState.questions);
      if(aiEvaluateVisitQaBtn) aiEvaluateVisitQaBtn.disabled = !aiState.questions.length;
      setAiQaNotice('Questions generated. Fill answers and evaluate.', 'good');
    }

    async function evaluateAiVisitQa(){
      if(!aiState.visitContext || !Array.isArray(aiState.questions)){
        setAiQaNotice('Start the AI Q&A first.', 'bad');
        return;
      }

      const answers = [];
      if(aiQaQuestions){
        const inputs = Array.from(aiQaQuestions.querySelectorAll('input[data-aiq]'));
        for(const input of inputs){
          const id = String(input.getAttribute('data-aiq') || '').trim();
          const ans = String(input.value || '').trim();
          answers.push({ id, answer: ans });
        }
      }

      const qa = { questions: aiState.questions, answers };

      const fd = new FormData();
      fd.set('visitContext', JSON.stringify(aiState.visitContext));
      fd.set('qa', JSON.stringify(qa));
      if(aiState.photoBlob){
        fd.set('photo', aiState.photoBlob, 'visit.jpg');
      }

      setAiQaNotice('Evaluating answers…', '');
      const r = await api('/api/ai/visit-assistant/evaluate', { method: 'POST', body: fd });

      if(Array.isArray(r.results)){
        const lines = r.results.map(x => `${x.id}: ${x.status}${x.reason ? ` — ${x.reason}` : ''}`);
        addMsg(`Q&A results:\n${lines.join('\n')}`, 'bot');
      }
      if(r.overall){
        addMsg(`Overall: completed ${r.overall.completed}, in process ${r.overall.in_process}, not completed ${r.overall.not_completed}`, 'bot');
      }

      setAiQaNotice('Evaluation complete. See results in chat.', 'good');
    }

    if(aiStartVisitQaBtn){
      aiStartVisitQaBtn.addEventListener('click', () => {
        startAiVisitQa().catch((err) => {
          setAiQaNotice(err.message || 'Failed to start AI Q&A.', 'bad');
          addMsg(String(err.message || 'Failed to start AI Q&A.'), 'bot');
        });
      });
    }

    if(aiEvaluateVisitQaBtn){
      aiEvaluateVisitQaBtn.addEventListener('click', () => {
        evaluateAiVisitQa().catch((err) => {
          setAiQaNotice(err.message || 'Failed to evaluate answers.', 'bad');
          addMsg(String(err.message || 'Failed to evaluate answers.'), 'bot');
        });
      });
    }

    if(chatForm){
      chatForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const text = String(chatInput?.value || '').trim();
        if(!text) return;
        addMsg(text, 'user');
        if(chatInput) chatInput.value = '';

        aiChat(text)
          .then((reply) => {
            addMsg(reply || 'No response.', 'bot');
          })
          .catch((err) => {
            const msg = String(err && err.message ? err.message : 'AI request failed');
            addMsg(msg, 'bot');
          });
      });
    }

    $all('[data-quick]').forEach(btn => {
      btn.addEventListener('click', () => {
        const q = btn.getAttribute('data-quick') || '';
        if(chatInput){
          chatInput.value = q;
          chatInput.focus();
        }
      });
    });
  }

  function init(){
    const themeToggle = $('#themeToggle');
    if(themeToggle){
      themeToggle.addEventListener('click', toggleTheme);
      updateThemeToggle();
    }

    initRegister();
    initCaregiverLogin();
    initVisitForm();
    initPatientAuth();
    initPatientRegister();
    initDashboard();
    initPatientPortal();

    // optional: show logged in state in any page that has #whoami
    const who = $('#whoami');
    if(who){
      const auth = getAuth();
      if(!auth.loggedIn){
        who.textContent = 'Not signed in';
      }else{
        const role = getRole();
        if(role === 'caregiver'){
          fetchMe()
            .then((cg) => { who.textContent = `Signed in: ${cg.email}`; })
            .catch(() => { who.textContent = 'Signed in'; });
        }else if(role === 'patient'){
          fetchPatientMe()
            .then((pt) => { who.textContent = `Signed in: ${pt.patientId}`; })
            .catch(() => { who.textContent = 'Signed in'; });
        }else{
          who.textContent = 'Signed in';
        }
      }
    }
  }

  document.addEventListener('DOMContentLoaded', init);
})();
