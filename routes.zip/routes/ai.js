const express = require('express');
const multer = require('multer');

const { requireCaregiver } = require('../middleware/auth');

const router = express.Router();

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 6 * 1024 * 1024 }
});

function getOpenAiConfig() {
  const apiKey = String(process.env.GEMINI_API_KEY || '').trim();
  const chatModel = String(process.env.GEMINI_MODEL_CHAT || 'gemini-1.5-flash').trim();
  const visionModel = String(process.env.GEMINI_MODEL_VISION || 'gemini-1.5-flash').trim();

  return { apiKey, chatModel, visionModel };
}

async function getOpenAiClient() {
  const { apiKey } = getOpenAiConfig();
  if (!apiKey) return null;

  // eslint-disable-next-line global-require
  const { GoogleGenerativeAI } = require('@google/generative-ai');
  return new GoogleGenerativeAI(apiKey);
}

function systemPrompt() {
  return [
    'You are the CareSynapse assistant for a caregiver home-visit app.',
    'Your job:',
    '- Ask the caregiver a short checklist of questions to ensure the visit is complete and safe.',
    '- Focus on the visit checklist tasks (e.g., medication reviewed, wound/skin check, fall-risk, hydration/nutrition, blood sugar, respiratory assessment, meds administered, dressing/wound care, mobility exercises, hygiene support, mental wellbeing, follow-up).',
    '- Mark each item as one of: completed, in_process, not_completed.',
    '- If an image is provided, describe what you see and cross-check it with the caregiver answers and visit findings.',
    '',
    'Rules:',
    '- Be concise; ask 5–8 questions max.',
    '- Do NOT give medical diagnosis; only checklist-style verification and documentation help.',
    '- If information is missing, ask a question for it.',
    '- Output JSON only when asked for JSON.'
  ].join('\n');
}

function safeJsonParse(text) {
  try {
    return JSON.parse(text);
  } catch {
    return null;
  }
}

function toGeminiParts({ text, imageBuffer, imageMime }) {
  const parts = [];
  if (text) parts.push({ text });
  if (imageBuffer && imageBuffer.length) {
    parts.push({
      inlineData: {
        data: Buffer.from(imageBuffer).toString('base64'),
        mimeType: String(imageMime || 'image/jpeg')
      }
    });
  }
  return parts;
}

function normalizeMessages(messages) {
  return messages
    .filter((m) => m && (m.role === 'user' || m.role === 'assistant') && typeof m.content === 'string')
    .slice(-12)
    .map((m) => ({ role: m.role, content: String(m.content).slice(0, 4000) }));
}

function toTranscript(messages) {
  const lines = [];
  for (const m of messages) {
    const who = m.role === 'assistant' ? 'Assistant' : 'User';
    lines.push(`${who}: ${m.content}`);
  }
  return lines.join('\n');
}

router.post('/chat', requireCaregiver, async (req, res) => {
  const body = req.body || {};
  const messages = Array.isArray(body.messages) ? body.messages : [];

  const client = await getOpenAiClient();
  if (!client) {
    return res.status(503).json({
      error: 'AI is not configured. Set GEMINI_API_KEY in .env and restart the server.'
    });
  }

  const { chatModel } = getOpenAiConfig();
  const trimmed = normalizeMessages(messages);

  const prompt = [
    systemPrompt(),
    '',
    'Conversation:',
    toTranscript(trimmed),
    '',
    'Reply as the assistant. Keep it concise.'
  ].join('\n');

  try {
    const model = client.getGenerativeModel({ model: chatModel });
    const r = await model.generateContent({
      contents: [{ role: 'user', parts: [{ text: prompt }] }],
      generationConfig: { temperature: 0.2 }
    });

    const text = r && r.response ? (r.response.text() || '') : '';
    return res.json({ message: text });
  } catch (err) {
    return res.status(500).json({ error: err && err.message ? err.message : 'AI request failed' });
  }
});

// Start a structured Q&A for the latest visit (or a provided visit context)
router.post('/visit-assistant/start', requireCaregiver, upload.single('photo'), async (req, res) => {
  const body = req.body || {};
  const visitContextRaw = String(body.visitContext || '').trim();
  const visitContext = safeJsonParse(visitContextRaw) || {};

  const client = await getOpenAiClient();
  if (!client) {
    // Fallback: deterministic questions, no vision.
    const questions = [
      { id: 'vitals', question: 'Did you record BP, pulse, SpO₂, and temperature?', status: 'not_completed' },
      { id: 'location', question: 'Did you capture GPS and confirm the address?', status: 'not_completed' },
      { id: 'photo', question: 'Did you capture a clear photo proof of the visit?', status: 'not_completed' },
      { id: 'findings', question: 'Did you write symptoms/findings in detail?', status: 'not_completed' },
      { id: 'followup', question: 'Any follow-up action needed (medicine/test/referral)?', status: 'in_process' }
    ];
    return res.json({
      mode: 'fallback',
      imageInsights: null,
      questions
    });
  }

  const { visionModel } = getOpenAiConfig();
  const file = req.file;

  const prompt = {
    visitContext,
    taskKeys: [
      'medicationReviewed',
      'woundSkinCheck',
      'fallRiskCheck',
      'hydrationNutrition',
      'bloodSugarChecked',
      'respiratoryAssessment',
      'medicationAdministered',
      'dressingOrWoundCare',
      'mobilityExercisesGuided',
      'hygieneSupport',
      'mentalWellbeingCheck',
      'followUpScheduled'
    ]
  };

  try {
    const model = client.getGenerativeModel({ model: visionModel });
    const textPrompt = [
      systemPrompt(),
      '',
      'Create a short visit verification questionnaire.',
      'Return JSON ONLY with this shape:',
      '{"imageInsights":{"summary":string,"redFlags":string[]},"questions":[{"id":string,"question":string,"expected":string,"status":"not_completed"|"in_process"|"completed"}]}',
      'Use the provided visitContext and checklist taskKeys to decide what to ask.',
      'If image is present: describe what is visible (non-medical) and add redFlags if the image seems unrelated/unclear.',
      `visitContext: ${JSON.stringify(prompt.visitContext)}`
    ].join('\n');

    const r = await model.generateContent({
      contents: [{ role: 'user', parts: toGeminiParts({ text: textPrompt, imageBuffer: file && file.buffer, imageMime: file && file.mimetype }) }],
      generationConfig: { temperature: 0.2 }
    });

    const text = r && r.response ? (r.response.text() || '') : '';
    const json = safeJsonParse(text);
    if (!json || !Array.isArray(json.questions)) {
      return res.json({ mode: 'llm', message: text, imageInsights: null, questions: [] });
    }

    return res.json({ mode: 'llm', ...json });
  } catch (err) {
    return res.status(500).json({ error: err && err.message ? err.message : 'AI request failed' });
  }
});

// Evaluate caregiver answers (and optionally cross-check image)
router.post('/visit-assistant/evaluate', requireCaregiver, upload.single('photo'), async (req, res) => {
  const body = req.body || {};
  const visitContext = safeJsonParse(String(body.visitContext || '').trim()) || {};
  const qa = safeJsonParse(String(body.qa || '').trim()) || {};

  const client = await getOpenAiClient();
  if (!client) {
    return res.status(503).json({ error: 'AI is not configured. Set GEMINI_API_KEY in .env and restart the server.' });
  }

  const { visionModel } = getOpenAiConfig();
  const file = req.file;

  try {
    const model = client.getGenerativeModel({ model: visionModel });
    const textPrompt = [
      systemPrompt(),
      '',
      'Evaluate the caregiver answers to the questionnaire.',
      'Return JSON ONLY with this shape:',
      '{"results":[{"id":string,"status":"completed"|"in_process"|"not_completed","reason":string}],"overall":{"completed":number,"in_process":number,"not_completed":number}}',
      'Use visitContext and QA. If image is present, cross-check for obvious mismatch (unclear/unrelated).',
      `visitContext: ${JSON.stringify(visitContext)}`,
      `qa: ${JSON.stringify(qa)}`
    ].join('\n');

    const r = await model.generateContent({
      contents: [{ role: 'user', parts: toGeminiParts({ text: textPrompt, imageBuffer: file && file.buffer, imageMime: file && file.mimetype }) }],
      generationConfig: { temperature: 0.1 }
    });

    const text = r && r.response ? (r.response.text() || '') : '';
    const json = safeJsonParse(text);
    if (!json || !Array.isArray(json.results) || !json.overall) {
      return res.json({ mode: 'llm', message: text });
    }

    return res.json({ mode: 'llm', ...json });
  } catch (err) {
    return res.status(500).json({ error: err && err.message ? err.message : 'AI request failed' });
  }
});

module.exports = router;
