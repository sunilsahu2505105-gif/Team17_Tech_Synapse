const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const { getDb } = require('../db');
const { requireCaregiver, getJwtSecret } = require('../middleware/auth');

const router = express.Router();

function signToken(caregiver) {
  return jwt.sign(
    { sub: caregiver.id, email: caregiver.email, role: 'caregiver' },
    getJwtSecret(),
    { expiresIn: '7d' }
  );
}

function sanitizeCaregiver(row) {
  if (!row) return null;
  const {
    password_hash: _passwordHash,
    ...rest
  } = row;
  return rest;
}

router.post('/register', async (req, res) => {
  const body = req.body || {};

  const fullName = String(body.fullName || '').trim();
  const phone = String(body.phone || '').trim();
  const aadhaar = String(body.aadhaar || '').trim();
  const experienceYears = Number(body.experienceYears);
  const specialization = String(body.specialization || 'General Care').trim();
  const city = String(body.city || '').trim();
  const languages = String(body.languages || '').trim();
  const shift = String(body.shift || 'Flexible').trim();
  const regNo = String(body.regNo || '').trim();
  const email = String(body.email || '').trim().toLowerCase();
  const password = String(body.password || '').trim();

  if (!fullName || !phone || !aadhaar || !email || !password) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  if (!/^\d{10}$/.test(phone)) return res.status(400).json({ error: 'Phone must be 10 digits' });
  if (!/^\d{12}$/.test(aadhaar)) return res.status(400).json({ error: 'Aadhaar must be 12 digits' });
  if (!Number.isFinite(experienceYears) || experienceYears < 0 || experienceYears > 60) {
    return res.status(400).json({ error: 'Experience must be 0–60' });
  }

  const db = await getDb();

  const existing = await db.get('SELECT id FROM caregivers WHERE email = ?', email);
  if (existing) return res.status(409).json({ error: 'Email already registered' });

  const passwordHash = await bcrypt.hash(password, 10);

  const result = await db.run(
    `INSERT INTO caregivers (
      full_name, phone, aadhaar, experience_years,
      specialization, city, languages, shift, reg_no,
      email, password_hash
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)` ,
    fullName, phone, aadhaar, experienceYears,
    specialization, city, languages, shift, regNo,
    email, passwordHash
  );

  const caregiver = await db.get('SELECT * FROM caregivers WHERE id = ?', result.lastID);
  const token = signToken(caregiver);

  return res.json({ token, caregiver: sanitizeCaregiver(caregiver) });
});

router.post('/login', async (req, res) => {
  const body = req.body || {};
  const email = String(body.email || '').trim().toLowerCase();
  const password = String(body.password || '').trim();

  if (!email || !password) return res.status(400).json({ error: 'Email and password required' });

  const db = await getDb();
  const caregiver = await db.get('SELECT * FROM caregivers WHERE email = ?', email);
  if (!caregiver) return res.status(401).json({ error: 'Invalid credentials' });

  const ok = await bcrypt.compare(password, caregiver.password_hash);
  if (!ok) return res.status(401).json({ error: 'Invalid credentials' });

  const token = signToken(caregiver);
  return res.json({ token, caregiver: sanitizeCaregiver(caregiver) });
});

router.get('/me', requireCaregiver, async (req, res) => {
  const db = await getDb();
  const id = Number(req.user?.sub);
  if (!id) return res.status(401).json({ error: 'Invalid token' });

  const caregiver = await db.get('SELECT * FROM caregivers WHERE id = ?', id);
  if (!caregiver) return res.status(404).json({ error: 'Caregiver not found' });

  return res.json({ caregiver: sanitizeCaregiver(caregiver) });
});

module.exports = router;
