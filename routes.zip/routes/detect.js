const express = require('express');
const path = require('path');
const fs = require('fs');
const multer = require('multer');
const { spawn } = require('child_process');

const router = express.Router();

function ensureDetectUploadsDir() {
  const dir = path.join(__dirname, '..', 'uploads', 'detect');
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  return dir;
}

const upload = multer({
  storage: multer.diskStorage({
    destination: (_req, _file, cb) => cb(null, ensureDetectUploadsDir()),
    filename: (_req, file, cb) => {
      const ext = path.extname(file.originalname || '').slice(0, 10) || '.jpg';
      const safeExt = ext.match(/^\.[a-z0-9]+$/i) ? ext : '.jpg';
      cb(null, `detect_${Date.now()}_${Math.random().toString(16).slice(2)}${safeExt}`);
    }
  }),
  limits: { fileSize: 6 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    const ok = String(file.mimetype || '').toLowerCase().startsWith('image/');
    cb(ok ? null : new Error('Only image uploads are allowed'), ok);
  }
});

function runYoloDetect(imagePath) {
  return new Promise((resolve, reject) => {
    const python = String(process.env.YOLO_PYTHON || 'python').trim() || 'python';
    const scriptPath = path.join(__dirname, '..', 'ml', 'yolo_detect.py');
    const model = String(process.env.YOLO_MODEL || 'yolov8n.pt').trim() || 'yolov8n.pt';
    const conf = String(process.env.YOLO_CONF || '0.25').trim() || '0.25';

    const child = spawn(python, [scriptPath, '--image', imagePath, '--model', model, '--conf', conf], {
      stdio: ['ignore', 'pipe', 'pipe'],
      windowsHide: true
    });

    let stdout = '';
    let stderr = '';

    const killTimer = setTimeout(() => {
      try { child.kill('SIGKILL'); } catch {}
      reject(new Error('YOLO detection timed out'));
    }, 60000);

    child.stdout.on('data', (d) => { stdout += d.toString('utf8'); });
    child.stderr.on('data', (d) => { stderr += d.toString('utf8'); });

    child.on('error', (err) => {
      clearTimeout(killTimer);
      reject(err);
    });

    child.on('close', (code) => {
      clearTimeout(killTimer);
      const out = String(stdout || '').trim();
      if (code !== 0) {
        const msg = (stderr || out || '').trim();
        return reject(new Error(msg || `YOLO process failed (exit ${code})`));
      }
      try {
        const json = JSON.parse(out);
        return resolve(json);
      } catch {
        return reject(new Error(`YOLO output was not valid JSON. Output: ${out.slice(0, 400)}`));
      }
    });
  });
}

router.post('/', upload.single('photo'), async (req, res) => {
  const file = req.file;
  if (!file) return res.status(400).json({ error: 'Image is required' });

  try {
    const result = await runYoloDetect(file.path);
    return res.json({ ok: true, result });
  } catch (err) {
    return res.status(503).json({
      error: err && err.message ? err.message : 'YOLO detection failed. Ensure Python + ultralytics are installed.'
    });
  } finally {
    try { fs.unlinkSync(file.path); } catch {}
  }
});

module.exports = router;
