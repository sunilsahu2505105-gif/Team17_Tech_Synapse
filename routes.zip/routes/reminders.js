const express = require('express');

const { getDb } = require('../db');
const { requirePatient } = require('../middleware/auth');

const router = express.Router();

function isTimeOfDay(v) {
  return /^\d{2}:\d{2}$/.test(String(v || ''));
}

function isIsoDate(v) {
  const d = new Date(String(v || ''));
  return Number.isFinite(d.getTime());
}

router.get('/reminders', requirePatient, async (req, res) => {
  const db = await getDb();
  const patientId = Number(req.user?.sub);
  if (!patientId) return res.status(401).json({ error: 'Invalid token' });

  const meds = await db.all(
    `SELECT id, med_name as medName, time_of_day as timeOfDay, notes, enabled, created_at as createdAt
     FROM medication_reminders
     WHERE patient_id = ?
     ORDER BY time_of_day ASC, id ASC`,
    patientId
  );

  const tests = await db.all(
    `SELECT id, test_name as testName, due_at as dueAt, notes, enabled, created_at as createdAt
     FROM test_reminders
     WHERE patient_id = ?
     ORDER BY due_at ASC, id ASC`,
    patientId
  );

  return res.json({ medications: meds, tests });
});

router.post('/reminders/medications', requirePatient, async (req, res) => {
  const body = req.body || {};
  const medName = String(body.medName || '').trim();
  const timeOfDay = String(body.timeOfDay || '').trim();
  const notes = String(body.notes || '').trim();

  if (!medName || !timeOfDay) return res.status(400).json({ error: 'medName and timeOfDay are required' });
  if (!isTimeOfDay(timeOfDay)) return res.status(400).json({ error: 'timeOfDay must be HH:MM' });

  const db = await getDb();
  const patientId = Number(req.user?.sub);
  if (!patientId) return res.status(401).json({ error: 'Invalid token' });

  const r = await db.run(
    `INSERT INTO medication_reminders (patient_id, med_name, time_of_day, notes)
     VALUES (?, ?, ?, ?)`,
    patientId,
    medName,
    timeOfDay,
    notes || null
  );

  const row = await db.get(
    `SELECT id, med_name as medName, time_of_day as timeOfDay, notes, enabled, created_at as createdAt
     FROM medication_reminders
     WHERE id = ?`,
    r.lastID
  );

  return res.status(201).json({ medication: row });
});

router.delete('/reminders/medications/:id', requirePatient, async (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isFinite(id) || id <= 0) return res.status(400).json({ error: 'Invalid id' });

  const db = await getDb();
  const patientId = Number(req.user?.sub);
  if (!patientId) return res.status(401).json({ error: 'Invalid token' });

  const existing = await db.get('SELECT id FROM medication_reminders WHERE id = ? AND patient_id = ?', id, patientId);
  if (!existing) return res.status(404).json({ error: 'Not found' });

  await db.run('DELETE FROM medication_reminders WHERE id = ?', id);
  return res.json({ ok: true });
});

router.post('/reminders/tests', requirePatient, async (req, res) => {
  const body = req.body || {};
  const testName = String(body.testName || '').trim();
  const dueAt = String(body.dueAt || '').trim();
  const notes = String(body.notes || '').trim();

  if (!testName || !dueAt) return res.status(400).json({ error: 'testName and dueAt are required' });
  if (!isIsoDate(dueAt)) return res.status(400).json({ error: 'dueAt must be a valid date/time' });

  const db = await getDb();
  const patientId = Number(req.user?.sub);
  if (!patientId) return res.status(401).json({ error: 'Invalid token' });

  const r = await db.run(
    `INSERT INTO test_reminders (patient_id, test_name, due_at, notes)
     VALUES (?, ?, ?, ?)`,
    patientId,
    testName,
    new Date(dueAt).toISOString(),
    notes || null
  );

  const row = await db.get(
    `SELECT id, test_name as testName, due_at as dueAt, notes, enabled, created_at as createdAt
     FROM test_reminders
     WHERE id = ?`,
    r.lastID
  );

  return res.status(201).json({ test: row });
});

router.delete('/reminders/tests/:id', requirePatient, async (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isFinite(id) || id <= 0) return res.status(400).json({ error: 'Invalid id' });

  const db = await getDb();
  const patientId = Number(req.user?.sub);
  if (!patientId) return res.status(401).json({ error: 'Invalid token' });

  const existing = await db.get('SELECT id FROM test_reminders WHERE id = ? AND patient_id = ?', id, patientId);
  if (!existing) return res.status(404).json({ error: 'Not found' });

  await db.run('DELETE FROM test_reminders WHERE id = ?', id);
  return res.json({ ok: true });
});

module.exports = router;
