const express = require('express');
const jwt = require('jsonwebtoken');
const multer = require('multer');
const sharp = require('sharp');

const { getDb } = require('../db');
const { getJwtSecret, requirePatient } = require('../middleware/auth');

const router = express.Router();

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 6 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    const ok = String(file.mimetype || '').toLowerCase().startsWith('image/');
    cb(ok ? null : new Error('Only image uploads are allowed'), ok);
  }
});

async function normalizeFaceLikeImage(buffer) {
  // Normalize to reduce variance across devices (rotation/size/format)
  // Using entropy crop helps keep the face centered more often than plain resize.
  return sharp(buffer)
    .rotate()
    .resize(320, 320, { fit: 'cover', position: 'entropy' })
    .jpeg({ quality: 85 })
    .toBuffer();
}

async function computeAHashBits(buffer) {
  const pixels = await sharp(buffer)
    .rotate()
    .resize(8, 8, { fit: 'cover', position: 'entropy' })
    .grayscale()
    .raw()
    .toBuffer();

  let sum = 0;
  for (const v of pixels) sum += v;
  const avg = sum / pixels.length;

  let bits = '';
  for (const v of pixels) bits += (v >= avg) ? '1' : '0';
  return bits; // 64 chars
}

async function computeDHashBits(buffer) {
  // 9x8 then horizontal gradient comparisons => 64 bits
  const w = 9;
  const h = 8;
  const pixels = await sharp(buffer)
    .rotate()
    .resize(w, h, { fit: 'cover', position: 'entropy' })
    .grayscale()
    .raw()
    .toBuffer();

  let bits = '';
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w - 1; x++) {
      const left = pixels[y * w + x];
      const right = pixels[y * w + x + 1];
      bits += (left > right) ? '1' : '0';
    }
  }
  return bits; // 64 chars
}

function median(values) {
  if (!values.length) return 0;
  const a = values.slice().sort((x, y) => x - y);
  const mid = Math.floor(a.length / 2);
  return a.length % 2 ? a[mid] : (a[mid - 1] + a[mid]) / 2;
}

function precomputeCosTable(N) {
  const table = Array.from({ length: N }, () => Array(N).fill(0));
  for (let u = 0; u < N; u++) {
    for (let x = 0; x < N; x++) {
      table[u][x] = Math.cos((Math.PI / N) * (x + 0.5) * u);
    }
  }
  return table;
}

function dct2(pixels, N) {
  // Separable DCT-II
  const cosTable = precomputeCosTable(N);
  const alpha = (u) => (u === 0 ? Math.sqrt(1 / N) : Math.sqrt(2 / N));

  const tmp = Array.from({ length: N }, () => Array(N).fill(0));
  for (let u = 0; u < N; u++) {
    const au = alpha(u);
    for (let y = 0; y < N; y++) {
      let sum = 0;
      for (let x = 0; x < N; x++) {
        sum += pixels[y * N + x] * cosTable[u][x];
      }
      tmp[u][y] = au * sum;
    }
  }

  const out = Array.from({ length: N }, () => Array(N).fill(0));
  for (let u = 0; u < N; u++) {
    for (let v = 0; v < N; v++) {
      const av = alpha(v);
      let sum = 0;
      for (let y = 0; y < N; y++) {
        sum += tmp[u][y] * cosTable[v][y];
      }
      out[u][v] = av * sum;
    }
  }

  return out;
}

async function computePHashBits(buffer) {
  // pHash: 32x32 grayscale -> DCT -> top-left 8x8
  const N = 32;
  const pixelsBuf = await sharp(buffer)
    .rotate()
    .resize(N, N, { fit: 'cover', position: 'entropy' })
    .grayscale()
    .raw()
    .toBuffer();

  const pixels = Array.from(pixelsBuf, (v) => Number(v));
  const coeffs = dct2(pixels, N);

  const vals = [];
  for (let u = 0; u < 8; u++) {
    for (let v = 0; v < 8; v++) {
      if (u === 0 && v === 0) continue;
      vals.push(coeffs[u][v]);
    }
  }
  const med = median(vals);

  let bits = '';
  for (let u = 0; u < 8; u++) {
    for (let v = 0; v < 8; v++) {
      const c = coeffs[u][v];
      bits += (c > med) ? '1' : '0';
    }
  }
  return bits; // 64 chars
}

async function computePhotoPrint(buffer) {
  const normalized = await normalizeFaceLikeImage(buffer);
  const [aHash, dHash, pHash] = await Promise.all([
    computeAHashBits(normalized),
    computeDHashBits(normalized),
    computePHashBits(normalized)
  ]);

  return { normalized, aHash, dHash, pHash };
}

function hamming(a, b) {
  if (!a || !b || a.length !== b.length) return Number.MAX_SAFE_INTEGER;
  let d = 0;
  for (let i = 0; i < a.length; i++) if (a[i] !== b[i]) d++;
  return d;
}

async function generateUniquePatientId(db) {
  for (let i = 0; i < 8; i++) {
    const n = Math.floor(100000 + Math.random() * 900000);
    const id = `PT-${n}`;
    const exists = await db.get('SELECT id FROM patients WHERE patient_identifier = ?', id);
    if (!exists) return id;
  }
  // fallback: timestamp-based
  const id = `PT-${Date.now()}`;
  return id;
}

function signPatientToken(patient) {
  return jwt.sign(
    { sub: patient.id, role: 'patient', patientIdentifier: patient.patient_identifier },
    getJwtSecret(),
    { expiresIn: '30d' }
  );
}

router.post('/register', upload.single('photo'), async (req, res) => {
  const body = req.body || {};
  const file = req.file;

  const patientName = String(body.patientName || '').trim();
  const patientPhone = String(body.patientPhone || '').trim();
  const aadhaar = String(body.aadhaar || '').trim();

  if (!patientName || !patientPhone || !aadhaar) {
    return res.status(400).json({ error: 'patientName, patientPhone, aadhaar are required' });
  }
  if (!/^\d{10}$/.test(patientPhone)) {
    return res.status(400).json({ error: 'Mobile must be 10 digits' });
  }
  if (!/^\d{12}$/.test(aadhaar)) {
    return res.status(400).json({ error: 'Aadhaar must be 12 digits' });
  }
  if (!file) return res.status(400).json({ error: 'Photo is required' });
  if (!file.buffer || !file.buffer.length) return res.status(400).json({ error: 'Invalid photo upload' });

  const db = await getDb();

  const aadhaarExists = await db.get('SELECT id FROM patients WHERE aadhaar = ?', aadhaar);
  if (aadhaarExists) {
    return res.status(409).json({ error: 'Aadhaar already registered' });
  }

  const patientId = await generateUniquePatientId(db);
  const fp = await computePhotoPrint(file.buffer);
  const photoMime = 'image/jpeg';

  const r = await db.run(
    `INSERT INTO patients (
       patient_name,
       patient_identifier,
       patient_phone,
       aadhaar,
       photo_path,
       photo_hash,
       photo_blob,
       photo_mime,
       photo_hash_ahash,
       photo_hash_dhash,
       photo_hash_phash
     ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    patientName,
    patientId,
    patientPhone,
    aadhaar,
    '',
    fp.aHash,
    fp.normalized,
    photoMime,
    fp.aHash,
    fp.dHash,
    fp.pHash
  );

  const patient = await db.get('SELECT * FROM patients WHERE id = ?', r.lastID);
  const token = signPatientToken(patient);

  return res.status(201).json({
    token,
    patient: {
      patientId: patient.patient_identifier,
      patientName: patient.patient_name,
      patientPhone: patient.patient_phone
    }
  });
});

// Patient login + live camera verification (image similarity)
router.post('/verify', upload.single('photo'), async (req, res) => {
  const body = req.body || {};
  const patientIdentifier = String(body.patientId || '').trim();
  const patientPhone = String(body.patientPhone || '').trim();
  const file = req.file;

  if (!patientIdentifier || !patientPhone) {
    return res.status(400).json({ error: 'Patient ID and phone are required' });
  }
  if (!/^\d{10}$/.test(patientPhone)) {
    return res.status(400).json({ error: 'Patient phone must be 10 digits' });
  }
  if (!file) return res.status(400).json({ error: 'Live photo is required for verification' });
  if (!file.buffer || !file.buffer.length) return res.status(400).json({ error: 'Invalid photo upload' });

  const db = await getDb();
  const patient = await db.get('SELECT * FROM patients WHERE patient_identifier = ?', patientIdentifier);
  if (!patient) {
    return res.status(404).json({ error: 'Patient not found' });
  }
  if (String(patient.patient_phone) !== patientPhone) {
    return res.status(401).json({ error: 'Invalid credentials' });
  }

  let storedA = String(patient.photo_hash_ahash || patient.photo_hash || '').trim();
  let storedD = String(patient.photo_hash_dhash || '').trim();
  let storedP = String(patient.photo_hash_phash || '').trim();

  // Backfill: if this patient was registered before we added stronger hashes,
  // recompute from the stored photo blob (if present) and update the record.
  if ((!storedD || !storedP) && patient.photo_blob) {
    try {
      const backfilled = await computePhotoPrint(patient.photo_blob);
      storedA = storedA || backfilled.aHash;
      storedD = storedD || backfilled.dHash;
      storedP = storedP || backfilled.pHash;
      await db.run(
        `UPDATE patients
         SET photo_hash = COALESCE(NULLIF(photo_hash,''), ?),
             photo_hash_ahash = COALESCE(NULLIF(photo_hash_ahash,''), ?),
             photo_hash_dhash = COALESCE(NULLIF(photo_hash_dhash,''), ?),
             photo_hash_phash = COALESCE(NULLIF(photo_hash_phash,''), ?)
         WHERE id = ?`,
        storedA,
        storedA,
        storedD,
        storedP,
        patient.id
      );
    } catch {
      // If backfill fails, continue with whatever we have.
    }
  }

  if (!storedA) {
    return res.status(400).json({ error: 'No registered photo for this patient' });
  }

  const fp = await computePhotoPrint(file.buffer);
  const distA = hamming(storedA, fp.aHash);
  const distD = storedD ? hamming(storedD, fp.dHash) : Number.MAX_SAFE_INTEGER;
  const distP = storedP ? hamming(storedP, fp.pHash) : Number.MAX_SAFE_INTEGER;

  // More tolerant scoring (reduces false rejects) while still requiring similarity.
  // Each hash is 64 bits; normalized distance is in [0,1].
  const nA = distA / 64;
  const nD = distD / 64;
  const nP = distP / 64;

  // Prefer pHash when available; otherwise use aHash+dHash.
  const score = (storedP ? (0.55 * nP + 0.30 * nD + 0.15 * nA) : (0.60 * nD + 0.40 * nA));

  // Threshold chosen to reduce false rejects; tighten later if needed.
  // Typical same-person, similar framing tends to be well below ~0.30.
  const ok = score <= 0.33 || (distP <= 24) || (distD <= 18 && distA <= 18);

  if (!ok) {
    const debugEnabled = String(process.env.DEBUG_VERIFY || '').trim() === '1';
    return res.status(401).json({
      error: 'Photo verification failed',
      ...(debugEnabled ? { debug: { distA, distD, distP, score } } : {})
    });
  }

  const token = signPatientToken(patient);
  return res.json({
    token,
    patient: {
      patientId: patient.patient_identifier,
      patientName: patient.patient_name,
      patientPhone: patient.patient_phone
    }
  });
});

router.post('/login', async (req, res) => {
  const body = req.body || {};
  const patientIdentifier = String(body.patientId || '').trim();
  const patientPhone = String(body.patientPhone || '').trim();

  if (!patientIdentifier || !patientPhone) {
    return res.status(400).json({ error: 'Patient ID and phone are required' });
  }

  if (!/^\d{10}$/.test(patientPhone)) {
    return res.status(400).json({ error: 'Patient phone must be 10 digits' });
  }

  const db = await getDb();
  const patient = await db.get(
    'SELECT * FROM patients WHERE patient_identifier = ?',
    patientIdentifier
  );

  if (!patient) return res.status(404).json({ error: 'Patient not found' });

  if (String(patient.patient_phone) !== patientPhone) {
    return res.status(401).json({ error: 'Invalid credentials' });
  }

  const token = signPatientToken(patient);
  return res.json({ token, patient: { patientId: patient.patient_identifier, patientName: patient.patient_name, patientPhone: patient.patient_phone } });
});

router.get('/me', requirePatient, async (req, res) => {
  const db = await getDb();
  const patientId = Number(req.user?.sub);
  if (!patientId) return res.status(401).json({ error: 'Invalid token' });

  const patient = await db.get('SELECT * FROM patients WHERE id = ?', patientId);
  if (!patient) return res.status(404).json({ error: 'Patient not found' });

  return res.json({
    patient: {
      patientId: patient.patient_identifier,
      patientName: patient.patient_name,
      patientPhone: patient.patient_phone
    }
  });
});

module.exports = router;
