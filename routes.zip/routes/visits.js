const express = require('express');
const path = require('path');
const fs = require('fs');
const multer = require('multer');

const { getDb } = require('../db');
const { requireCaregiver, requirePatient } = require('../middleware/auth');

const router = express.Router();

function ensureUploadsDir() {
  const dir = path.join(__dirname, '..', 'uploads');
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  return dir;
}

const upload = multer({
  storage: multer.diskStorage({
    destination: (_req, _file, cb) => cb(null, ensureUploadsDir()),
    filename: (_req, file, cb) => {
      const ext = path.extname(file.originalname || '').slice(0, 10) || '.jpg';
      const safeExt = ext.match(/^\.[a-z0-9]+$/i) ? ext : '.jpg';
      cb(null, `visit_${Date.now()}_${Math.random().toString(16).slice(2)}${safeExt}`);
    }
  }),
  limits: { fileSize: 6 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    const ok = String(file.mimetype || '').toLowerCase().startsWith('image/');
    cb(ok ? null : new Error('Only image uploads are allowed'), ok);
  }
});

router.get('/visits', requireCaregiver, async (req, res) => {
  const db = await getDb();
  const caregiverId = Number(req.user?.sub);

  const limit = Math.max(1, Math.min(50, Number(req.query.limit || 10)));

  const rows = await db.all(
    `SELECT
      v.id,
      v.visit_date as visitDate,
      v.checked_at as checkedAt,
      v.location_lat as locationLat,
      v.location_lng as locationLng,
      v.location_address as locationAddress,
      v.vitals_json as vitalsJson,
      v.checklist_json as checklistJson,
      v.detection_json as detectionJson,
      v.findings,
      v.image_path as imagePath,
      v.notes,
      v.created_at as createdAt,
      p.patient_name as patientName,
      p.patient_identifier as patientId,
      p.patient_phone as patientPhone
    FROM visits v
    JOIN patients p ON p.id = v.patient_id
    WHERE v.caregiver_id = ?
    ORDER BY v.created_at DESC
    LIMIT ?`,
    caregiverId,
    limit
  );

  return res.json({ visits: rows });
});

router.get('/patient/visits', requirePatient, async (req, res) => {
  const db = await getDb();
  const patientDbId = Number(req.user?.sub);
  const limit = Math.max(1, Math.min(50, Number(req.query.limit || 20)));

  const rows = await db.all(
    `SELECT
      v.id,
      v.visit_date as visitDate,
      v.checked_at as checkedAt,
      v.location_lat as locationLat,
      v.location_lng as locationLng,
      v.location_address as locationAddress,
      v.vitals_json as vitalsJson,
      v.checklist_json as checklistJson,
      v.detection_json as detectionJson,
      v.findings,
      v.image_path as imagePath,
      v.notes,
      v.created_at as createdAt,
      c.full_name as caregiverName,
      c.phone as caregiverPhone,
      c.email as caregiverEmail
    FROM visits v
    JOIN caregivers c ON c.id = v.caregiver_id
    WHERE v.patient_id = ?
    ORDER BY v.created_at DESC
    LIMIT ?`,
    patientDbId,
    limit
  );

  return res.json({ visits: rows });
});

router.post('/visits', requireCaregiver, upload.single('photo'), async (req, res) => {
  const body = req.body || {};
  const file = req.file;

  const caregiverId = Number(req.user?.sub);
  const patientName = String(body.patientName || '').trim();
  const patientId = String(body.patientId || '').trim();
  const patientPhone = String(body.patientPhone || '').trim();
  const visitDate = String(body.visitDate || '').trim();
  const checkedAt = String(body.checkedAt || '').trim();
  const address = String(body.address || '').trim();
  const lat = Number(body.lat);
  const lng = Number(body.lng);
  const findings = String(body.findings || '').trim();
  const vitalsJson = String(body.vitalsJson || '').trim();
  const checklistJson = String(body.checklistJson || '').trim();
  const detectionJson = String(body.detectionJson || '').trim();
  const notes = String(body.notes || '').trim();

  if (!patientName || !patientId || !patientPhone || !visitDate) return res.status(400).json({ error: 'Missing required patient fields' });
  if (!checkedAt) return res.status(400).json({ error: 'Missing timestamp' });
  if (!address) return res.status(400).json({ error: 'Address is required' });
  if (!Number.isFinite(lat) || !Number.isFinite(lng)) return res.status(400).json({ error: 'GPS latitude/longitude required' });
  if (!findings) return res.status(400).json({ error: 'Symptoms/findings are required' });
  if (!vitalsJson) return res.status(400).json({ error: 'Vitals are required' });
  if (!checklistJson) return res.status(400).json({ error: 'Checklist is required' });
  if (!file) return res.status(400).json({ error: 'Image is required' });

  try { JSON.parse(vitalsJson); } catch { return res.status(400).json({ error: 'Vitals JSON invalid' }); }
  try { JSON.parse(checklistJson); } catch { return res.status(400).json({ error: 'Checklist JSON invalid' }); }
  if (detectionJson) {
    try { JSON.parse(detectionJson); } catch { return res.status(400).json({ error: 'Detection JSON invalid' }); }
  }

  if (!/^\d{10}$/.test(patientPhone)) {
    return res.status(400).json({ error: 'Patient phone must be 10 digits' });
  }

  const db = await getDb();

  // Upsert patient by identifier
  const existing = await db.get('SELECT id FROM patients WHERE patient_identifier = ?', patientId);
  let patientRowId;

  if (!existing) {
    const r = await db.run(
      'INSERT INTO patients (patient_name, patient_identifier, patient_phone) VALUES (?, ?, ?)',
      patientName,
      patientId,
      patientPhone
    );
    patientRowId = r.lastID;
  } else {
    patientRowId = existing.id;
    await db.run(
      'UPDATE patients SET patient_name = ?, patient_phone = ? WHERE id = ?',
      patientName,
      patientPhone,
      patientRowId
    );
  }

  const vr = await db.run(
    `INSERT INTO visits (
      caregiver_id, patient_id, visit_date,
      checked_at, location_lat, location_lng, location_address,
      vitals_json, checklist_json, detection_json, findings, image_path,
      notes
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    caregiverId,
    patientRowId,
    visitDate,
    checkedAt,
    lat,
    lng,
    address,
    vitalsJson,
    checklistJson,
    detectionJson || '{}',
    findings,
    `/uploads/${file.filename}`,
    notes || null
  );

  const visit = await db.get(
    `SELECT
      v.id,
      v.visit_date as visitDate,
      v.checked_at as checkedAt,
      v.location_lat as locationLat,
      v.location_lng as locationLng,
      v.location_address as locationAddress,
      v.vitals_json as vitalsJson,
      v.checklist_json as checklistJson,
      v.detection_json as detectionJson,
      v.findings,
      v.image_path as imagePath,
      v.notes,
      v.created_at as createdAt,
      p.patient_name as patientName,
      p.patient_identifier as patientId,
      p.patient_phone as patientPhone
    FROM visits v
    JOIN patients p ON p.id = v.patient_id
    WHERE v.id = ?`,
    vr.lastID
  );

  return res.status(201).json({ visit });
});

module.exports = router;
