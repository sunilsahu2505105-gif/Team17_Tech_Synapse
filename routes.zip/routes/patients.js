const express = require('express');

const { getDb } = require('../db');
const { requireCaregiver } = require('../middleware/auth');

const router = express.Router();

// Caregiver-only patient lookup (so patient details are entered once)
router.get('/lookup', requireCaregiver, async (req, res) => {
  const patientId = String(req.query.patientId || '').trim();
  const patientPhone = String(req.query.patientPhone || '').trim();

  if (!patientId || !patientPhone) {
    return res.status(400).json({ error: 'patientId and patientPhone are required' });
  }

  if (!/^\d{10}$/.test(patientPhone)) {
    return res.status(400).json({ error: 'Patient phone must be 10 digits' });
  }

  const db = await getDb();
  const patient = await db.get('SELECT * FROM patients WHERE patient_identifier = ?', patientId);
  if (!patient) return res.status(404).json({ error: 'Patient not found' });

  if (String(patient.patient_phone) !== patientPhone) {
    return res.status(401).json({ error: 'Patient phone does not match' });
  }

  return res.json({
    patient: {
      patientId: patient.patient_identifier,
      patientName: patient.patient_name,
      patientPhone: patient.patient_phone
    }
  });
});

// Caregiver-only: fetch a patient's registered photo
// Note: this endpoint is protected (requires JWT). The frontend fetches it with Authorization and renders via object URL.
router.get('/photo', requireCaregiver, async (req, res) => {
  const patientId = String(req.query.patientId || '').trim();
  if (!patientId) return res.status(400).json({ error: 'patientId is required' });

  const db = await getDb();
  const row = await db.get(
    'SELECT photo_blob as photoBlob, photo_mime as photoMime FROM patients WHERE patient_identifier = ?',
    patientId
  );

  if (!row || !row.photoBlob) return res.status(404).json({ error: 'Patient photo not found' });

  res.setHeader('Cache-Control', 'no-store');
  res.type(String(row.photoMime || 'image/jpeg'));
  return res.send(row.photoBlob);
});

module.exports = router;
