const jwt = require('jsonwebtoken');

function getJwtSecret() {
  return String(process.env.JWT_SECRET || 'dev-secret-change-me');
}

function requireAuth(req, res, next) {
  const header = String(req.headers.authorization || '');
  const m = header.match(/^Bearer\s+(.+)$/i);
  const token = m ? m[1] : null;

  if (!token) return res.status(401).json({ error: 'Missing Authorization Bearer token' });

  try {
    const payload = jwt.verify(token, getJwtSecret());
    req.user = payload;
    return next();
  } catch {
    return res.status(401).json({ error: 'Invalid or expired token' });
  }
}

function requireCaregiver(req, res, next) {
  return requireAuth(req, res, () => {
    if (req.user?.role !== 'caregiver') return res.status(403).json({ error: 'Caregiver access required' });
    return next();
  });
}

function requirePatient(req, res, next) {
  return requireAuth(req, res, () => {
    if (req.user?.role !== 'patient') return res.status(403).json({ error: 'Patient access required' });
    return next();
  });
}

module.exports = { requireAuth, requireCaregiver, requirePatient, getJwtSecret };
